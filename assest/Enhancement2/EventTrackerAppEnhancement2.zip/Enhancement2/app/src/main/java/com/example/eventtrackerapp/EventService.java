package com.example.eventtrackerapp;

import java.util.Collections;
import java.util.List;

/*
 * Coordinates event validation, searching, sorting,
 * and repository operations.
 */
public class EventService {

    private final EventRepository eventRepository;

    public EventService(EventRepository eventRepository) {
        if (eventRepository == null) {
            throw new IllegalArgumentException(
                    "EventRepository cannot be null."
            );
        }

        this.eventRepository = eventRepository;
    }

    public List<Event> getAllEvents() {
        try {
            return eventRepository.getAllEvents();
        } catch (RuntimeException exception) {
            return Collections.emptyList();
        }
    }

    /*
     * Applies the enhanced event searching and merge-sort logic.
     */
    public List<Event> filterAndSortEvents(
            List<Event> events,
            String query,
            EventSortOption sortOption
    ) {
        try {
            return EventAlgorithms.filterAndSort(
                    events,
                    query,
                    sortOption
            );
        } catch (RuntimeException exception) {
            return Collections.emptyList();
        }
    }

    public Event getEventById(int eventId) {
        if (eventId < 1) {
            return null;
        }

        try {
            return eventRepository.getEventById(eventId);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    /*
     * Validates and then creates or updates an event.
     */
    public ServiceResult saveEvent(Event event) {
        ServiceResult validationResult = EventValidator.validate(event);

        if (!validationResult.isSuccessful()) {
            return validationResult;
        }

        try {
            boolean saved = eventRepository.saveEvent(event);

            if (!saved) {
                return ServiceResult.failure(
                        "The event could not be saved."
                );
            }

            if (event.isNew()) {
                return ServiceResult.success(
                        "Event created successfully."
                );
            }

            return ServiceResult.success(
                    "Event updated successfully."
            );
        } catch (RuntimeException exception) {
            return ServiceResult.failure(
                    "An unexpected error occurred while saving the event."
            );
        }
    }

    public ServiceResult deleteEvent(int eventId) {
        if (eventId < 1) {
            return ServiceResult.failure(
                    "A valid event must be selected."
            );
        }

        try {
            boolean deleted = eventRepository.deleteEvent(eventId);

            if (deleted) {
                return ServiceResult.success(
                        "Event deleted successfully."
                );
            }

            return ServiceResult.failure(
                    "The event could not be deleted."
            );
        } catch (RuntimeException exception) {
            return ServiceResult.failure(
                    "An unexpected error occurred while deleting the event."
            );
        }
    }
}