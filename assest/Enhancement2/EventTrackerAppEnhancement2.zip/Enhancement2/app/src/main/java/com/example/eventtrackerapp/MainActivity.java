package com.example.eventtrackerapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {

    // Navigation and action buttons
    private Button buttonAddEvent;
    private Button buttonSmsSettings;
    private Button buttonLogout;

    // Search, filter, and sort controls
    private EditText editSearchEvents;
    private Spinner spinnerEventFilter;
    private Spinner spinnerSortEvents;

    // Event display controls
    private TableLayout tableEvents;
    private TextView textEmptyState;

    // Database and service dependencies
    private DatabaseHelper databaseHelper;
    private EventService eventService;

    /*
     * The complete event collection is loaded from SQLite and kept in
     * memory while the activity is active. Searches, filters, and sorts
     * are performed on this collection without querying the database
     * for every user interaction.
     */
    private List<Event> allEvents = Collections.emptyList();

    /*
     * These values represent the currently selected filtering and
     * sorting options.
     */
    private EventFilterOption selectedFilter =
            EventFilterOption.ALL_EVENTS;

    private EventSortOption selectedSortOption =
            EventSortOption.DATE_ASCENDING;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /*
         * Prevent unauthenticated users from accessing the event list.
         */
        if (!SessionManager.isLoggedIn(this)) {
            redirectToLogin();
            return;
        }

        setContentView(R.layout.activity_main);

        /*
         * Initialize dependencies and views before configuring the
         * spinners or registering listeners.
         */
        initializeDependencies();
        initializeViews();
        configureFilterSpinner();
        configureSortSpinner();
        configureListeners();
    }

    /*
     * Creates the database, repository, and service dependencies used
     * by this activity.
     */
    private void initializeDependencies() {
        databaseHelper = new DatabaseHelper(this);

        EventRepository eventRepository =
                new EventRepository(databaseHelper);

        eventService = new EventService(eventRepository);
    }

    /*
     * Connects the Java fields to the views defined in activity_main.xml.
     */
    private void initializeViews() {
        buttonAddEvent = findViewById(R.id.buttonAddEvent);
        buttonSmsSettings = findViewById(R.id.buttonSmsSettings);
        buttonLogout = findViewById(R.id.buttonLogout);

        editSearchEvents = findViewById(R.id.editSearchEvents);
        spinnerEventFilter = findViewById(R.id.spinnerEventFilter);
        spinnerSortEvents = findViewById(R.id.spinnerSortEvents);

        tableEvents = findViewById(R.id.tableEvents);
        textEmptyState = findViewById(R.id.textEmptyState);
    }

    /*
     * Configures the spinner containing the available event filters.
     */
    private void configureFilterSpinner() {
        ArrayAdapter<EventFilterOption> filterAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        EventFilterOption.values()
                );

        filterAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerEventFilter.setAdapter(filterAdapter);

        spinnerEventFilter.setSelection(
                EventFilterOption.ALL_EVENTS.ordinal()
        );
    }

    /*
     * Configures the spinner containing the available sorting options.
     */
    private void configureSortSpinner() {
        ArrayAdapter<EventSortOption> sortAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        EventSortOption.values()
                );

        sortAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerSortEvents.setAdapter(sortAdapter);

        spinnerSortEvents.setSelection(
                EventSortOption.DATE_ASCENDING.ordinal()
        );
    }

    /*
     * Registers all button, search, filter, and sort listeners.
     */
    private void configureListeners() {
        buttonAddEvent.setOnClickListener(
                view -> openAddEventScreen()
        );

        buttonSmsSettings.setOnClickListener(
                view -> openSmsSettingsScreen()
        );

        buttonLogout.setOnClickListener(
                view -> logout()
        );

        /*
         * Refresh the event table whenever the search query changes.
         */
        editSearchEvents.addTextChangedListener(
                new TextWatcher() {
                    @Override
                    public void beforeTextChanged(
                            CharSequence value,
                            int start,
                            int count,
                            int after
                    ) {
                        // No action required.
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence value,
                            int start,
                            int before,
                            int count
                    ) {
                        renderEvents();
                    }

                    @Override
                    public void afterTextChanged(Editable value) {
                        // No action required.
                    }
                }
        );

        /*
         * Refresh the event table whenever a sort option is selected.
         */
        spinnerSortEvents.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id
                    ) {
                        Object selectedItem =
                                parent.getItemAtPosition(position);

                        if (selectedItem instanceof EventSortOption) {
                            selectedSortOption =
                                    (EventSortOption) selectedItem;

                            renderEvents();
                        }
                    }

                    @Override
                    public void onNothingSelected(
                            AdapterView<?> parent
                    ) {
                        selectedSortOption =
                                EventSortOption.DATE_ASCENDING;

                        renderEvents();
                    }
                }
        );

        /*
         * Refresh the event table whenever a filter is selected.
         */
        spinnerEventFilter.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id
                    ) {
                        Object selectedItem =
                                parent.getItemAtPosition(position);

                        if (selectedItem instanceof EventFilterOption) {
                            selectedFilter =
                                    (EventFilterOption) selectedItem;

                            renderEvents();
                        }
                    }

                    @Override
                    public void onNothingSelected(
                            AdapterView<?> parent
                    ) {
                        selectedFilter =
                                EventFilterOption.ALL_EVENTS;

                        renderEvents();
                    }
                }
        );
    }

    /*
     * Reloads events whenever the activity returns to the foreground.
     * This allows newly created or edited events to appear immediately.
     */
    @Override
    protected void onResume() {
        super.onResume();

        if (!SessionManager.isLoggedIn(this)) {
            redirectToLogin();
            return;
        }

        loadEvents();
    }

    /*
     * Loads all events from the service into the in-memory collection.
     */
    private void loadEvents() {
        List<Event> loadedEvents = eventService.getAllEvents();

        if (loadedEvents == null) {
            allEvents = Collections.emptyList();
        } else {
            allEvents = loadedEvents;
        }

        renderEvents();
    }

    /*
     * Applies search, filtering, and sorting before rebuilding the table.
     * The EventAlgorithms utility performs the algorithmic operations:
     * 1. Case-insensitive multi-field searching.
     * 2. Date-based filtering.
     * 3. Stable chronological or alphabetical sorting.
     */
    private void renderEvents() {
        /*
         * Spinner listeners can occasionally run during view setup.
         * This check prevents the method from accessing uninitialized
         * table views.
         */
        if (tableEvents == null || textEmptyState == null) {
            return;
        }

        clearEventRows();

        String query = "";

        if (editSearchEvents != null) {
            query = editSearchEvents
                    .getText()
                    .toString()
                    .trim();
        }

        /*
         * displayedEvents only needs to be a local variable because this
         * activity creates TableRows directly instead of using a
         * RecyclerView or ListView adapter.
         */
        List<Event> displayedEvents =
                EventAlgorithms.filterAndSort(
                        allEvents,
                        query,
                        selectedFilter,
                        selectedSortOption
                );

        if (displayedEvents == null || displayedEvents.isEmpty()) {
            showEmptyState(query);
            return;
        }

        textEmptyState.setVisibility(View.GONE);

        for (Event event : displayedEvents) {
            addEventRow(event);
        }
    }

    /*
     * Displays the appropriate message when no events can be shown.
     */
    private void showEmptyState(String query) {
        textEmptyState.setVisibility(View.VISIBLE);

        if (allEvents == null || allEvents.isEmpty()) {
            textEmptyState.setText(
                    "No events have been saved. " +
                            "Select Add Event to create one."
            );
            return;
        }

        boolean hasSearchQuery =
                query != null && !query.trim().isEmpty();

        boolean hasDateFilter =
                selectedFilter != EventFilterOption.ALL_EVENTS;

        if (hasSearchQuery && hasDateFilter) {
            textEmptyState.setText(
                    "No events match your search and selected filter."
            );
        } else if (hasSearchQuery) {
            textEmptyState.setText(
                    "No events match your search."
            );
        } else if (hasDateFilter) {
            textEmptyState.setText(
                    "No events match the selected filter."
            );
        } else {
            textEmptyState.setText(
                    "No events are available."
            );
        }
    }

    /*
     * Removes the generated event rows but keeps the header row at
     * position zero.
     */
    private void clearEventRows() {
        int childCount = tableEvents.getChildCount();

        /*
         * Child zero contains the table header, so generated event rows
         * begin at index one.
         */
        if (childCount > 1) {
            tableEvents.removeViews(
                    1,
                    childCount - 1
            );
        }
    }

    /*
     * Creates and adds one table row for the supplied event.
     */
    private void addEventRow(Event event) {
        TableRow row = new TableRow(this);
        row.setPadding(4, 4, 4, 4);

        TextView titleView = createCell(
                event.getTitle(),
                2.0f
        );

        TextView dateView = createCell(
                event.getDate(),
                1.0f
        );

        TextView timeView = createCell(
                event.getTime(),
                1.0f
        );

        Button editButton = createEditButton(event);
        Button deleteButton = createDeleteButton(event);

        row.addView(titleView);
        row.addView(dateView);
        row.addView(timeView);
        row.addView(editButton);
        row.addView(deleteButton);

        row.setOnClickListener(
                view -> showEventDetails(event)
        );

        tableEvents.addView(row);
    }

    /*
     * Creates a formatted text cell for an event table row.
     */
    private TextView createCell(String text, float weight) {
        TextView textView = new TextView(this);

        TableRow.LayoutParams parameters =
                new TableRow.LayoutParams(
                        0,
                        TableRow.LayoutParams.WRAP_CONTENT,
                        weight
                );

        textView.setLayoutParams(parameters);

        if (text == null) {
            textView.setText("");
        } else {
            textView.setText(text);
        }

        textView.setPadding(8, 12, 8, 12);
        textView.setGravity(Gravity.CENTER);
        textView.setTextColor(Color.BLACK);

        return textView;
    }

    /*
     * Creates an Edit button for the supplied event.
     */
    private Button createEditButton(Event event) {
        Button button = new Button(this);

        button.setText("Edit");
        button.setTextColor(Color.WHITE);
        button.setBackgroundColor(
                Color.rgb(25, 118, 210)
        );

        button.setOnClickListener(view -> {
            Intent intent = new Intent(
                    MainActivity.this,
                    AddEventActivity.class
            );

            intent.putExtra(
                    "eventId",
                    event.getId()
            );

            startActivity(intent);
        });

        return button;
    }

    /*
     * Creates a Delete button for the supplied event.
     */
    private Button createDeleteButton(Event event) {
        Button button = new Button(this);

        button.setText("Delete");
        button.setTextColor(Color.WHITE);
        button.setBackgroundColor(
                Color.rgb(198, 40, 40)
        );

        button.setOnClickListener(
                view -> showDeleteConfirmation(event)
        );

        return button;
    }

    /*
     * Opens the screen used to create a new event.
     */
    private void openAddEventScreen() {
        Intent intent = new Intent(
                MainActivity.this,
                AddEventActivity.class
        );

        startActivity(intent);
    }

    /*
     * Opens the SMS permission and settings screen.
     */
    private void openSmsSettingsScreen() {
        Intent intent = new Intent(
                MainActivity.this,
                SmsPermissionActivity.class
        );

        startActivity(intent);
    }

    /*
     * Displays a confirmation dialog before deleting an event.
     */
    private void showDeleteConfirmation(Event event) {
        String eventTitle = event.getTitle();

        if (eventTitle == null || eventTitle.trim().isEmpty()) {
            eventTitle = "this event";
        } else {
            eventTitle = "\"" + eventTitle + "\"";
        }

        new AlertDialog.Builder(this)
                .setTitle("Delete Event")
                .setMessage(
                        "Are you sure you want to delete " +
                                eventTitle +
                                "?"
                )
                .setPositiveButton(
                        "Delete",
                        (dialog, which) -> deleteEvent(event)
                )
                .setNegativeButton("Cancel", null)
                .show();
    }

    /*
     * Deletes an event and reloads the table after a successful result.
     */
    private void deleteEvent(Event event) {
        ServiceResult result =
                eventService.deleteEvent(event.getId());

        Toast.makeText(
                this,
                result.getMessage(),
                Toast.LENGTH_SHORT
        ).show();

        if (result.isSuccessful()) {
            loadEvents();
        }
    }

    /*
     * Displays the complete information for the selected event.
     */
    private void showEventDetails(Event event) {
        String title = event.getTitle();

        if (title == null || title.trim().isEmpty()) {
            title = "Event Details";
        }

        String date = event.getDate();

        if (date == null || date.trim().isEmpty()) {
            date = "No date provided";
        }

        String time = event.getTime();

        if (time == null || time.trim().isEmpty()) {
            time = "No time provided";
        }

        String description = event.getDescription();

        if (description == null ||
                description.trim().isEmpty()) {

            description = "No description was provided.";
        }

        String message =
                "Date: " + date +
                        "\nTime: " + time +
                        "\n\n" + description;

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("Close", null)
                .show();
    }

    /*
     * Logs the current user out and returns to the login screen.
     */
    private void logout() {
        SessionManager.logout(this);

        Toast.makeText(
                this,
                "Logged out successfully.",
                Toast.LENGTH_SHORT
        ).show();

        redirectToLogin();
    }

    /*
     * Opens LoginActivity and clears the activity history.
     */
    private void redirectToLogin() {
        Intent intent = new Intent(
                MainActivity.this,
                LoginActivity.class
        );

        intent.setFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK |
                        Intent.FLAG_ACTIVITY_CLEAR_TASK
        );

        startActivity(intent);
        finish();
    }

    /*
     * Closes the database connection when the activity is destroyed.
     */
    @Override
    protected void onDestroy() {
        if (databaseHelper != null) {
            databaseHelper.close();
        }

        super.onDestroy();
    }
}