package com.example.eventtrackerapp;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class SmsPermissionActivity extends Activity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    Button buttonRequestSmsPermission;
    Button buttonDeclineSmsPermission;
    Button buttonReturnDashboard;
    TextView textSmsPermissionStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        buttonRequestSmsPermission = findViewById(R.id.buttonRequestSmsPermission);
        buttonDeclineSmsPermission = findViewById(R.id.buttonDeclineSmsPermission);
        buttonReturnDashboard = findViewById(R.id.buttonReturnDashboard);
        textSmsPermissionStatus = findViewById(R.id.textSmsPermissionStatus);

        updatePermissionStatus();

        buttonRequestSmsPermission.setOnClickListener(v -> requestSmsPermission());

        buttonDeclineSmsPermission.setOnClickListener(v -> {
            textSmsPermissionStatus.setText("Permission denied. Events will still save, but SMS reminders are disabled.");
        });

        buttonReturnDashboard.setOnClickListener(v -> finish());
    }

    private void requestSmsPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                textSmsPermissionStatus.setText("Permission already granted. SMS reminders are enabled.");
            } else {
                requestPermissions(
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_REQUEST_CODE
                );
            }
        } else {
            textSmsPermissionStatus.setText("SMS permission is enabled on this Android version.");
        }
    }

    private void updatePermissionStatus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                textSmsPermissionStatus.setText("SMS permission is currently enabled.");
            } else {
                textSmsPermissionStatus.setText("SMS permission is currently not enabled.");
            }
        } else {
            textSmsPermissionStatus.setText("SMS permission is enabled on this Android version.");
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                textSmsPermissionStatus.setText("Permission granted. SMS reminders are enabled.");

            } else {
                textSmsPermissionStatus.setText("Permission denied. SMS reminders are disabled.");
            }
        }
    }
}