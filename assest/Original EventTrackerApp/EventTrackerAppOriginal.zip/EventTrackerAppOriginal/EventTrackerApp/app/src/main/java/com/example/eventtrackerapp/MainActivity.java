package com.example.eventtrackerapp;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    Button buttonAddEvent;
    Button buttonSmsSettings;
    Button buttonLogout;

    TableLayout tableEvents;

    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!SessionManager.isLoggedIn(this)) {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return;
        }

        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);

        buttonAddEvent = findViewById(R.id.buttonAddEvent);
        buttonSmsSettings = findViewById(R.id.buttonSmsSettings);
        buttonLogout = findViewById(R.id.buttonLogout);
        tableEvents = findViewById(R.id.tableEvents);

        buttonAddEvent.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddEventActivity.class);
            startActivity(intent);
        });

        buttonSmsSettings.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SmsPermissionActivity.class);
            startActivity(intent);
        });

        buttonLogout.setOnClickListener(v -> {
            SessionManager.logout(MainActivity.this);

            Toast.makeText(MainActivity.this, "Logged out successfully.", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);

            finish();
        });

        loadEvents();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (SessionManager.isLoggedIn(this)) {
            loadEvents();
        }
    }

    private void loadEvents() {
        clearEventRows();

        Cursor cursor = databaseHelper.getAllEvents();

        if (cursor == null) {
            Toast.makeText(this, "Could not load events.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!cursor.moveToFirst()) {
            cursor.close();
            return;
        }

        do {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_ID));
            String title = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_TITLE));
            String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_DATE));
            String time = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_TIME));
            String description = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_DESCRIPTION));

            addEventRow(id, title, date, time, description);

        } while (cursor.moveToNext());

        cursor.close();
    }

    private void clearEventRows() {
        int childCount = tableEvents.getChildCount();

        if (childCount > 1) {
            tableEvents.removeViews(1, childCount - 1);
        }
    }

    private void addEventRow(int id, String title, String date, String time, String description) {
        TableRow row = new TableRow(this);
        row.setPadding(4, 4, 4, 4);

        TextView titleView = createCell(title);
        TextView dateView = createCell(date);
        TextView timeView = createCell(time);

        Button editButton = new Button(this);
        editButton.setText("Edit");
        editButton.setTextColor(Color.WHITE);
        editButton.setBackgroundColor(Color.rgb(25, 118, 210));

        editButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddEventActivity.class);
            intent.putExtra("eventId", id);
            startActivity(intent);
        });

        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");
        deleteButton.setTextColor(Color.WHITE);
        deleteButton.setBackgroundColor(Color.rgb(198, 40, 40));

        deleteButton.setOnClickListener(v -> {
            boolean deleted = databaseHelper.deleteEvent(id);

            if (deleted) {
                Toast.makeText(MainActivity.this, "Event deleted.", Toast.LENGTH_SHORT).show();
                loadEvents();
            } else {
                Toast.makeText(MainActivity.this, "Could not delete event.", Toast.LENGTH_SHORT).show();
            }
        });

        row.addView(titleView);
        row.addView(dateView);
        row.addView(timeView);
        row.addView(editButton);
        row.addView(deleteButton);

        tableEvents.addView(row);
    }

    private TextView createCell(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(8, 8, 8, 8);
        textView.setGravity(Gravity.CENTER);
        textView.setTextColor(Color.BLACK);

        return textView;
    }
}