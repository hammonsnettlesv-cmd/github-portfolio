package com.example.eventtrackerapp;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AddEventActivity extends Activity {

    TextView textAddEditTitle;

    EditText editEventTitle;
    EditText editEventDate;
    EditText editEventTime;
    EditText editEventDescription;

    Button buttonSaveEvent;
    Button buttonCancelEvent;

    DatabaseHelper databaseHelper;

    int eventId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!SessionManager.isLoggedIn(this)) {
            Toast.makeText(this, "Please log in first.", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(AddEventActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);

            finish();
            return;
        }

        setContentView(R.layout.activity_add_event);

        databaseHelper = new DatabaseHelper(this);

        textAddEditTitle = findViewById(R.id.textAddEditTitle);

        editEventTitle = findViewById(R.id.editEventTitle);
        editEventDate = findViewById(R.id.editEventDate);
        editEventTime = findViewById(R.id.editEventTime);
        editEventDescription = findViewById(R.id.editEventDescription);

        buttonSaveEvent = findViewById(R.id.buttonSaveEvent);
        buttonCancelEvent = findViewById(R.id.buttonCancelEvent);

        eventId = getIntent().getIntExtra("eventId", -1);

        if (eventId != -1) {
            textAddEditTitle.setText("Edit Event");
            loadEventData(eventId);
        } else {
            textAddEditTitle.setText("Add Event");
        }

        buttonSaveEvent.setOnClickListener(v -> saveEvent());

        buttonCancelEvent.setOnClickListener(v -> finish());
    }

    private void loadEventData(int eventId) {
        Cursor cursor = databaseHelper.getEventById(eventId);

        if (cursor != null && cursor.moveToFirst()) {
            String title = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_TITLE));
            String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_DATE));
            String time = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_TIME));
            String description = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_DESCRIPTION));

            editEventTitle.setText(title);
            editEventDate.setText(date);
            editEventTime.setText(time);
            editEventDescription.setText(description);

            cursor.close();
        } else {
            Toast.makeText(this, "Could not load event.", Toast.LENGTH_SHORT).show();

            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private void saveEvent() {
        String title = editEventTitle.getText().toString().trim();
        String date = editEventDate.getText().toString().trim();
        String time = editEventTime.getText().toString().trim();
        String description = editEventDescription.getText().toString().trim();

        if (title.isEmpty() || date.isEmpty() || time.isEmpty()) {
            Toast.makeText(this, "Please complete the title, date, and time fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (eventId == -1) {
            boolean result = databaseHelper.addEvent(title, date, time, description);

            if (result) {
                Toast.makeText(this, "Event saved.", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Could not save event.", Toast.LENGTH_SHORT).show();
            }
        } else {
            boolean updated = databaseHelper.updateEvent(eventId, title, date, time, description);

            if (updated) {
                Toast.makeText(this, "Event updated.", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Could not update event.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}