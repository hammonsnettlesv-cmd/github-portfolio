package com.example.eventtrackerapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class AddEventActivity extends Activity {

    private TextView textAddEditTitle;
    private EditText editEventTitle;
    private EditText editEventDate;
    private EditText editEventTime;
    private EditText editEventDescription;
    private Button buttonSaveEvent;
    private Button buttonCancelEvent;

    private DatabaseHelper databaseHelper;
    private EventService eventService;

    private int eventId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!SessionManager.isLoggedIn(this)) {
            redirectToLogin();
            return;
        }

        setContentView(R.layout.activity_add_event);

        initializeDependencies();
        initializeViews();
        configureScreen();
        configureListeners();
    }

    private void initializeDependencies() {
        databaseHelper = new DatabaseHelper(this);

        EventRepository eventRepository =
                new EventRepository(databaseHelper);

        eventService = new EventService(eventRepository);
    }

    private void initializeViews() {
        textAddEditTitle = findViewById(R.id.textAddEditTitle);
        editEventTitle = findViewById(R.id.editEventTitle);
        editEventDate = findViewById(R.id.editEventDate);
        editEventTime = findViewById(R.id.editEventTime);
        editEventDescription =
                findViewById(R.id.editEventDescription);
        buttonSaveEvent = findViewById(R.id.buttonSaveEvent);
        buttonCancelEvent = findViewById(R.id.buttonCancelEvent);
    }

    private void configureScreen() {
        eventId = getIntent().getIntExtra("eventId", -1);

        if (eventId == -1) {
            textAddEditTitle.setText("Add Event");
            return;
        }

        textAddEditTitle.setText("Edit Event");
        loadEvent(eventId);
    }

    private void configureListeners() {
        buttonSaveEvent.setOnClickListener(v -> saveEvent());
        buttonCancelEvent.setOnClickListener(v -> finish());
    }

    private void loadEvent(int id) {
        Event event = eventService.getEventById(id);

        if (event == null) {
            Toast.makeText(
                    this,
                    "The selected event could not be loaded.",
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        editEventTitle.setText(event.getTitle());
        editEventDate.setText(event.getDate());
        editEventTime.setText(event.getTime());
        editEventDescription.setText(event.getDescription());
    }

    private void saveEvent() {
        Event event = createEventFromInput();

        ServiceResult result = eventService.saveEvent(event);

        Toast.makeText(
                this,
                result.getMessage(),
                Toast.LENGTH_SHORT
        ).show();

        if (result.isSuccessful()) {
            finish();
        }
    }

    private Event createEventFromInput() {
        String title =
                editEventTitle.getText().toString().trim();

        String date =
                editEventDate.getText().toString().trim();

        String time =
                editEventTime.getText()
                        .toString()
                        .trim()
                        .toUpperCase(Locale.US);

        String description =
                editEventDescription.getText().toString().trim();

        if (eventId == -1) {
            return new Event(title, date, time, description);
        }

        return new Event(
                eventId,
                title,
                date,
                time,
                description
        );
    }

    private void redirectToLogin() {
        Toast.makeText(
                this,
                "Please log in first.",
                Toast.LENGTH_SHORT
        ).show();

        Intent intent =
                new Intent(AddEventActivity.this, LoginActivity.class);

        intent.setFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TASK
        );

        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        if (databaseHelper != null) {
            databaseHelper.close();
        }

        super.onDestroy();
    }
}