package com.example.eventtrackerapp;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Locale;

/* Contains validation rules for Event objects. */
public final class EventValidator {

    public static final int MAX_TITLE_LENGTH = 100;
    public static final int MAX_DESCRIPTION_LENGTH = 500;

    private EventValidator() {
        // Utility class; prevent construction.
    }

    /*
     * Validates the event fields used by the application.
     * Expected date format: MM/dd/yyyy
     * Expected time format: h:mm a
     */

    public static ServiceResult validate(Event event) {
        if (event == null) {
            return ServiceResult.failure("Event information is required.");
        }

        if (event.getTitle() == null || event.getTitle().trim().isEmpty()) {
            return ServiceResult.failure("Please enter an event title.");
        }

        if (event.getTitle().trim().length() > MAX_TITLE_LENGTH) {
            return ServiceResult.failure(
                    "The event title cannot exceed "
                            + MAX_TITLE_LENGTH
                            + " characters."
            );
        }

        if (event.getDate() == null || event.getDate().trim().isEmpty()) {
            return ServiceResult.failure("Please enter an event date.");
        }

        if (!matchesFormat(event.getDate().trim(), "MM/dd/yyyy")) {
            return ServiceResult.failure(
                    "Enter the date in MM/DD/YYYY format."
            );
        }

        if (event.getTime() == null || event.getTime().trim().isEmpty()) {
            return ServiceResult.failure("Please enter an event time.");
        }

        if (!matchesFormat(
                event.getTime().trim().toUpperCase(Locale.US),
                "h:mm a"
        )) {
            return ServiceResult.failure(
                    "Enter the time in h:mm AM/PM format."
            );
        }

        if (event.getDescription() != null
                && event.getDescription().trim().length()
                > MAX_DESCRIPTION_LENGTH) {

            return ServiceResult.failure(
                    "The description cannot exceed "
                            + MAX_DESCRIPTION_LENGTH
                            + " characters."
            );
        }

        return ServiceResult.success("Event information is valid.");
    }

    private static boolean matchesFormat(String value, String format) {
        SimpleDateFormat formatter =
                new SimpleDateFormat(format, Locale.US);

        formatter.setLenient(false);

        ParsePosition position = new ParsePosition(0);
        formatter.parse(value, position);

        return position.getIndex() == value.length()
                && position.getErrorIndex() < 0;
    }

}
