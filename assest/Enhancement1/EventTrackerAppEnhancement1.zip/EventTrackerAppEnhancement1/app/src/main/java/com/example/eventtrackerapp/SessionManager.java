package com.example.eventtrackerapp;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {

    public static boolean isLoggedIn(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(
                LoginActivity.PREFS_NAME,
                Context.MODE_PRIVATE
        );

        return sharedPreferences.getBoolean(LoginActivity.KEY_LOGGED_IN, false);
    }

    public static String getUsername(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(
                LoginActivity.PREFS_NAME,
                Context.MODE_PRIVATE
        );

        return sharedPreferences.getString(LoginActivity.KEY_USERNAME, "");
    }

    public static void saveLoginSession(Context context, String username) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(
                LoginActivity.PREFS_NAME,
                Context.MODE_PRIVATE
        );

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(LoginActivity.KEY_LOGGED_IN, true);
        editor.putString(LoginActivity.KEY_USERNAME, username);
        editor.apply();
    }

    public static void logout(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(
                LoginActivity.PREFS_NAME,
                Context.MODE_PRIVATE
        );

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(LoginActivity.KEY_LOGGED_IN, false);
        editor.remove(LoginActivity.KEY_USERNAME);
        editor.apply();
    }
}