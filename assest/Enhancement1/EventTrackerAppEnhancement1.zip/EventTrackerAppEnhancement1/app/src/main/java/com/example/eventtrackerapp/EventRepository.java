package com.example.eventtrackerapp;

import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

/*
 * Provides data-access operations for Event objects.
 * Activities should not directly use DatabaseHelper for event operations.
 */
public class EventRepository {

    private final DatabaseHelper databaseHelper;

    public EventRepository(DatabaseHelper databaseHelper) {
        if (databaseHelper == null) {
            throw new IllegalArgumentException(
                    "DatabaseHelper cannot be null."
            );
        }

        this.databaseHelper = databaseHelper;
    }

    /* Returns all events stored in the database. */
    public List<Event> getAllEvents() {
        List<Event> events = new ArrayList<>();
        Cursor cursor = null;

        try {
            cursor = databaseHelper.getAllEvents();

            if (cursor == null || !cursor.moveToFirst()) {
                return events;
            }

            do {
                events.add(createEventFromCursor(cursor));
            } while (cursor.moveToNext());

            return events;

        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    /* Returns an event by ID or null when no matching event exists */
    public Event getEventById(int eventId) {
        Cursor cursor = null;

        try {
            cursor = databaseHelper.getEventById(eventId);

            if (cursor == null || !cursor.moveToFirst()) {
                return null;
            }

            return createEventFromCursor(cursor);

        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    /* Inserts or updates an event depending on whether it already has an ID. */
    public boolean saveEvent(Event event) {
        if (event == null) {
            return false;
        }

        if (event.isNew()) {
            return databaseHelper.addEvent(
                    event.getTitle(),
                    event.getDate(),
                    event.getTime(),
                    event.getDescription()
            );
        }

        return databaseHelper.updateEvent(
                event.getId(),
                event.getTitle(),
                event.getDate(),
                event.getTime(),
                event.getDescription()
        );
    }

    public boolean deleteEvent(int eventId) {
        return databaseHelper.deleteEvent(eventId);
    }

    private Event createEventFromCursor(Cursor cursor) {
        int id = cursor.getInt(
                cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_ID)
        );

        String title = cursor.getString(
                cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_TITLE)
        );

        String date = cursor.getString(
                cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_DATE)
        );

        String time = cursor.getString(
                cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_TIME)
        );

        String description = cursor.getString(
                cursor.getColumnIndexOrThrow(
                        DatabaseHelper.EVENT_DESCRIPTION
                )
        );

        return new Event(id, title, date, time, description);
    }
}
