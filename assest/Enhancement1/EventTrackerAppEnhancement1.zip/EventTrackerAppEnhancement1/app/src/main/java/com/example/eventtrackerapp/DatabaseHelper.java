package com.example.eventtrackerapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "EventTracker.db";
    private static final int DATABASE_VERSION = 2;

    // Users table
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // Events table
    public static final String TABLE_EVENTS = "events";
    public static final String COL_EVENT_ID = "id";
    public static final String COL_EVENT_TITLE = "title";
    public static final String COL_EVENT_DATE = "date";
    public static final String COL_EVENT_TIME = "time";
    public static final String COL_EVENT_DESCRIPTION = "description";

    // Compatibility aliases for activity code
    public static final String EVENT_ID = COL_EVENT_ID;
    public static final String EVENT_TITLE = COL_EVENT_TITLE;
    public static final String EVENT_DATE = COL_EVENT_DATE;
    public static final String EVENT_TIME = COL_EVENT_TIME;
    public static final String EVENT_DESCRIPTION = COL_EVENT_DESCRIPTION;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT NOT NULL UNIQUE, " +
                COL_PASSWORD + " TEXT NOT NULL)";

        String createEventsTable = "CREATE TABLE " + TABLE_EVENTS + " (" +
                COL_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_EVENT_TITLE + " TEXT NOT NULL, " +
                COL_EVENT_DATE + " TEXT NOT NULL, " +
                COL_EVENT_TIME + " TEXT NOT NULL, " +
                COL_EVENT_DESCRIPTION + " TEXT NOT NULL DEFAULT '')";

        db.execSQL(createUsersTable);
        db.execSQL(createEventsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);

        onCreate(db);
    }

    // Create/add a new user
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);

        return result != -1;
    }

    // Compatibility method for LoginActivity
    public boolean createUser(String username, String password) {
        return addUser(username, password);
    }

    // Validate login
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_USERS,
                null,
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password},
                null,
                null,
                null
        );

        boolean isValid = cursor.getCount() > 0;
        cursor.close();

        return isValid;
    }

    // Check if username already exists
    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_USERS,
                null,
                COL_USERNAME + "=?",
                new String[]{username},
                null,
                null,
                null
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();

        return exists;
    }

    // Add event with location
    public boolean addEvent(String title, String date, String time, String description) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_EVENT_TITLE, title);
        values.put(COL_EVENT_DATE, date);
        values.put(COL_EVENT_TIME, time);
        values.put(COL_EVENT_DESCRIPTION, description);

        long result = db.insert(TABLE_EVENTS, null, values);

        return result != -1;
    }

    // Get all events
    public Cursor getAllEvents() {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                TABLE_EVENTS,
                null,
                null,
                null,
                null,
                null,
                COL_EVENT_DATE + " ASC"
        );
    }

    // Get one event by ID
    public Cursor getEventById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                TABLE_EVENTS,
                null,
                COL_EVENT_ID + "=?",
                new String[]{String.valueOf(id)},
                null,
                null,
                null
        );
    }

    // Update event with location
    public boolean updateEvent(int id, String title, String date, String time, String description) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_EVENT_TITLE, title);
        values.put(COL_EVENT_DATE, date);
        values.put(COL_EVENT_TIME, time);
        values.put(COL_EVENT_DESCRIPTION, description);

        int result = db.update(
                TABLE_EVENTS,
                values,
                COL_EVENT_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }

    // Delete event
    public boolean deleteEvent(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(
                TABLE_EVENTS,
                COL_EVENT_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }
}