package com.example.eventtrackerapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends Activity {

    private Button buttonAddEvent;
    private Button buttonSmsSettings;
    private Button buttonLogout;
    private TableLayout tableEvents;
    private TextView textEmptyState;

    private DatabaseHelper databaseHelper;
    private EventService eventService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!SessionManager.isLoggedIn(this)) {
            redirectToLogin();
            return;
        }

        setContentView(R.layout.activity_main);

        initializeDependencies();
        initializeViews();
        configureListeners();
    }

    private void initializeDependencies() {
        databaseHelper = new DatabaseHelper(this);

        EventRepository eventRepository =
                new EventRepository(databaseHelper);

        eventService = new EventService(eventRepository);
    }

    private void initializeViews() {
        buttonAddEvent = findViewById(R.id.buttonAddEvent);
        buttonSmsSettings = findViewById(R.id.buttonSmsSettings);
        buttonLogout = findViewById(R.id.buttonLogout);
        tableEvents = findViewById(R.id.tableEvents);
        textEmptyState = findViewById(R.id.textEmptyState);
    }

    private void configureListeners() {
        buttonAddEvent.setOnClickListener(v -> openAddEventScreen());

        buttonSmsSettings.setOnClickListener(
                v -> openSmsSettingsScreen()
        );

        buttonLogout.setOnClickListener(v -> logout());
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (!SessionManager.isLoggedIn(this)) {
            redirectToLogin();
            return;
        }

        loadEvents();
    }

    private void openAddEventScreen() {
        Intent intent =
                new Intent(MainActivity.this, AddEventActivity.class);

        startActivity(intent);
    }

    private void openSmsSettingsScreen() {
        Intent intent =
                new Intent(
                        MainActivity.this,
                        SmsPermissionActivity.class
                );

        startActivity(intent);
    }

    private void loadEvents() {
        clearEventRows();

        List<Event> events = eventService.getAllEvents();

        if (events.isEmpty()) {
            textEmptyState.setVisibility(View.VISIBLE);
            return;
        }

        textEmptyState.setVisibility(View.GONE);

        for (Event event : events) {
            addEventRow(event);
        }
    }

    private void clearEventRows() {
        int childCount = tableEvents.getChildCount();

        // Keep child zero because it contains the table header.
        if (childCount > 1) {
            tableEvents.removeViews(1, childCount - 1);
        }
    }

    private void addEventRow(Event event) {
        TableRow row = new TableRow(this);
        row.setPadding(4, 4, 4, 4);

        TextView titleView = createCell(
                event.getTitle(),
                2.0f
        );

        TextView dateView = createCell(
                event.getDate(),
                1.0f
        );

        TextView timeView = createCell(
                event.getTime(),
                1.0f
        );

        Button editButton = createEditButton(event);
        Button deleteButton = createDeleteButton(event);

        row.addView(titleView);
        row.addView(dateView);
        row.addView(timeView);
        row.addView(editButton);
        row.addView(deleteButton);

        row.setOnClickListener(v -> showEventDetails(event));

        tableEvents.addView(row);
    }

    private TextView createCell(String text, float weight) {
        TextView textView = new TextView(this);

        TableRow.LayoutParams parameters =
                new TableRow.LayoutParams(
                        0,
                        TableRow.LayoutParams.WRAP_CONTENT,
                        weight
                );

        textView.setLayoutParams(parameters);
        textView.setText(text);
        textView.setPadding(8, 12, 8, 12);
        textView.setGravity(Gravity.CENTER);
        textView.setTextColor(Color.BLACK);

        return textView;
    }

    private Button createEditButton(Event event) {
        Button button = new Button(this);

        button.setText("Edit");
        button.setTextColor(Color.WHITE);
        button.setBackgroundColor(Color.rgb(25, 118, 210));

        button.setOnClickListener(v -> {
            Intent intent =
                    new Intent(
                            MainActivity.this,
                            AddEventActivity.class
                    );

            intent.putExtra("eventId", event.getId());
            startActivity(intent);
        });

        return button;
    }

    private Button createDeleteButton(Event event) {
        Button button = new Button(this);

        button.setText("Delete");
        button.setTextColor(Color.WHITE);
        button.setBackgroundColor(Color.rgb(198, 40, 40));

        button.setOnClickListener(
                v -> showDeleteConfirmation(event)
        );

        return button;
    }

    private void showDeleteConfirmation(Event event) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Event")
                .setMessage(
                        "Are you sure you want to delete \""
                                + event.getTitle()
                                + "\"?"
                )
                .setPositiveButton(
                        "Delete",
                        (dialog, which) -> deleteEvent(event)
                )
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteEvent(Event event) {
        ServiceResult result =
                eventService.deleteEvent(event.getId());

        Toast.makeText(
                this,
                result.getMessage(),
                Toast.LENGTH_SHORT
        ).show();

        if (result.isSuccessful()) {
            loadEvents();
        }
    }

    private void showEventDetails(Event event) {
        String description = event.getDescription();

        if (description == null || description.trim().isEmpty()) {
            description = "No description was provided.";
        }

        String message =
                "Date: " + event.getDate()
                        + "\nTime: " + event.getTime()
                        + "\n\n" + description;

        new AlertDialog.Builder(this)
                .setTitle(event.getTitle())
                .setMessage(message)
                .setPositiveButton("Close", null)
                .show();
    }

    private void logout() {
        SessionManager.logout(this);

        Toast.makeText(
                this,
                "Logged out successfully.",
                Toast.LENGTH_SHORT
        ).show();

        redirectToLogin();
    }

    private void redirectToLogin() {
        Intent intent =
                new Intent(MainActivity.this, LoginActivity.class);

        intent.setFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TASK
        );

        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        if (databaseHelper != null) {
            databaseHelper.close();
        }

        super.onDestroy();
    }
}