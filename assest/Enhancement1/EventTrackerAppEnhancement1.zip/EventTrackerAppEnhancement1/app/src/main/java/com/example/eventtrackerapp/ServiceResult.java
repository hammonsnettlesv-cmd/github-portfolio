package com.example.eventtrackerapp;

/* The result of a business-layer operation. */
public class ServiceResult {
    private final boolean successful;
    private final String message;

    private ServiceResult(boolean successful, String message) {
        this.successful = successful;
        this.message = message;
    }

    public static ServiceResult success(String message) {
        return new ServiceResult(true, message);
    }

    public static ServiceResult failure(String message) {
        return new ServiceResult(false, message);
    }

    public boolean isSuccessful() {
        return successful;
    }

    public String getMessage() {
        return message;
    }
}
