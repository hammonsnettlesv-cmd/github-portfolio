package com.example.eventtrackerapp;

/* One event managed by the application */
public class Event {
    private int id;
    private String title;
    private String date;
    private String time;
    private String description;

    public Event(
            int id,
            String title,
            String date,
            String time,
            String description
    ) {
        this.id = id;
        this.title = title;
        this.date = date;
        this.time = time;
        this.description = description;
    }

    /* Creates an Event that has not been inserted into the database. */
    public Event(
            String title,
            String date,
            String time,
            String description
    ) {
        this(-1, title, date, time, description);
    }

    public int getId() {
        return id;
    }

    public boolean isNew() {
        return id == -1;
    }

    public String getTitle() {
        return title;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getDescription() {
        return description;
    }
}
