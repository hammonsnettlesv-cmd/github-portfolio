package com.example.eventtrackerapp;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {

    private static final String PREFS_NAME = "EventTrackerPrefs";
    private static final String KEY_LOGGED_IN = "loggedIn";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_USER_ID = "userId";

    public static boolean isLoggedIn(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(
                PREFS_NAME,
                Context.MODE_PRIVATE
        );

        return preferences.getBoolean(KEY_LOGGED_IN, false)
                && preferences.getLong(KEY_USER_ID, -1L) > 0;
    }

    public static long getUserId(Context context) {
        return context.getSharedPreferences(
                PREFS_NAME,
                Context.MODE_PRIVATE
        ).getLong(KEY_USER_ID, -1L);
    }

    public static String getUsername(Context context) {
        return context.getSharedPreferences(
                PREFS_NAME,
                Context.MODE_PRIVATE
        ).getString(KEY_USERNAME, "");
    }

    public static void saveLoginSession(
            Context context,
            long userId,
            String username
    ) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_LOGGED_IN, true)
                .putLong(KEY_USER_ID, userId)
                .putString(KEY_USERNAME, username)
                .apply();
    }

    public static void logout(Context context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .remove(KEY_LOGGED_IN)
                .remove(KEY_USER_ID)
                .remove(KEY_USERNAME)
                .apply();
    }
}