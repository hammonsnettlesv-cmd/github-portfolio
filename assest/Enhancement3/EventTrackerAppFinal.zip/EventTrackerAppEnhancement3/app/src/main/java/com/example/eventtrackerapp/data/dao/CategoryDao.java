package com.example.eventtrackerapp.data.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.eventtrackerapp.data.entity.CategoryEntity;

import java.util.List;

@Dao
public interface CategoryDao {

    @Insert(onConflict = OnConflictStrategy.ABORT)
    long insert(CategoryEntity category);

    @Query(
            "UPDATE categories SET " +
                    "name = :name, description = :description " +
                    "WHERE id = :categoryId AND user_id = :userId"
    )
    int updateForUser(
            long categoryId,
            long userId,
            String name,
            String description
    );

    @Query(
            "SELECT * FROM categories " +
                    "WHERE user_id = :userId " +
                    "ORDER BY name COLLATE NOCASE"
    )
    List<CategoryEntity> getAllForUser(long userId);

    @Query(
            "DELETE FROM categories " +
                    "WHERE id = :categoryId AND user_id = :userId"
    )
    int deleteById(long categoryId, long userId);
}