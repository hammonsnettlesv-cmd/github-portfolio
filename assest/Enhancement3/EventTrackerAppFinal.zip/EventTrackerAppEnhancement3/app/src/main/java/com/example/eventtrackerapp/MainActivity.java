package com.example.eventtrackerapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.eventtrackerapp.data.AppDatabase;
import com.example.eventtrackerapp.data.repository.EventRepository;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private Button buttonAddEvent;
    private Button buttonSmsSettings;
    private Button buttonLogout;

    private EditText editSearchEvents;
    private Spinner spinnerEventFilter;
    private Spinner spinnerSortEvents;

    private TableLayout tableEvents;
    private TextView textEmptyState;

    private EventRepository eventRepository;

    private final ExecutorService databaseExecutor =
            Executors.newSingleThreadExecutor();

    private List<Event> allEvents =
            Collections.emptyList();

    private EventFilterOption selectedFilter =
            EventFilterOption.ALL_EVENTS;

    private EventSortOption selectedSortOption =
            EventSortOption.DATE_ASCENDING;

    private long currentUserId = -1L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!SessionManager.isLoggedIn(this)) {
            redirectToLogin();
            return;
        }

        currentUserId =
                SessionManager.getUserId(this);

        if (currentUserId <= 0) {
            SessionManager.logout(this);
            redirectToLogin();
            return;
        }

        setContentView(R.layout.activity_main);

        initializeDependencies();
        initializeViews();
        configureFilterSpinner();
        configureSortSpinner();
        configureListeners();
    }

    private void initializeDependencies() {
        AppDatabase database =
                AppDatabase.getInstance(
                        getApplicationContext()
                );

        eventRepository =
                new EventRepository(database.eventDao());
    }

    private void initializeViews() {
        buttonAddEvent =
                findViewById(R.id.buttonAddEvent);

        buttonSmsSettings =
                findViewById(R.id.buttonSmsSettings);

        buttonLogout =
                findViewById(R.id.buttonLogout);

        editSearchEvents =
                findViewById(R.id.editSearchEvents);

        spinnerEventFilter =
                findViewById(R.id.spinnerEventFilter);

        spinnerSortEvents =
                findViewById(R.id.spinnerSortEvents);

        tableEvents =
                findViewById(R.id.tableEvents);

        textEmptyState =
                findViewById(R.id.textEmptyState);
    }

    private void configureFilterSpinner() {
        ArrayAdapter<EventFilterOption> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        EventFilterOption.values()
                );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerEventFilter.setAdapter(adapter);

        spinnerEventFilter.setSelection(
                EventFilterOption.ALL_EVENTS.ordinal()
        );
    }

    private void configureSortSpinner() {
        ArrayAdapter<EventSortOption> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        EventSortOption.values()
                );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerSortEvents.setAdapter(adapter);

        spinnerSortEvents.setSelection(
                EventSortOption.DATE_ASCENDING.ordinal()
        );
    }

    private void configureListeners() {
        buttonAddEvent.setOnClickListener(
                view -> openAddEventScreen()
        );

        buttonSmsSettings.setOnClickListener(
                view -> openSmsSettingsScreen()
        );

        buttonLogout.setOnClickListener(
                view -> logout()
        );

        editSearchEvents.addTextChangedListener(
                new TextWatcher() {
                    @Override
                    public void beforeTextChanged(
                            CharSequence value,
                            int start,
                            int count,
                            int after
                    ) {
                        // No action required.
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence value,
                            int start,
                            int before,
                            int count
                    ) {
                        renderEvents();
                    }

                    @Override
                    public void afterTextChanged(
                            Editable value
                    ) {
                        // No action required.
                    }
                }
        );

        spinnerSortEvents.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id
                    ) {
                        Object selected =
                                parent.getItemAtPosition(position);

                        if (selected instanceof EventSortOption) {
                            selectedSortOption =
                                    (EventSortOption) selected;

                            renderEvents();
                        }
                    }

                    @Override
                    public void onNothingSelected(
                            AdapterView<?> parent
                    ) {
                        selectedSortOption =
                                EventSortOption.DATE_ASCENDING;

                        renderEvents();
                    }
                }
        );

        spinnerEventFilter.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id
                    ) {
                        Object selected =
                                parent.getItemAtPosition(position);

                        if (selected instanceof EventFilterOption) {
                            selectedFilter =
                                    (EventFilterOption) selected;

                            renderEvents();
                        }
                    }

                    @Override
                    public void onNothingSelected(
                            AdapterView<?> parent
                    ) {
                        selectedFilter =
                                EventFilterOption.ALL_EVENTS;

                        renderEvents();
                    }
                }
        );
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (!SessionManager.isLoggedIn(this)) {
            redirectToLogin();
            return;
        }

        currentUserId =
                SessionManager.getUserId(this);

        if (currentUserId <= 0) {
            SessionManager.logout(this);
            redirectToLogin();
            return;
        }

        loadEvents();
    }

    /*
     * Loads Room data on a background thread.
     */
    private void loadEvents() {
        if (eventRepository == null || currentUserId <= 0) {
            return;
        }

        databaseExecutor.execute(() -> {
            List<Event> loadedEvents;
            Exception loadingError = null;

            try {
                loadedEvents =
                        eventRepository.getAllEvents(
                                currentUserId
                        );
            } catch (Exception exception) {
                loadedEvents = Collections.emptyList();
                loadingError = exception;
            }

            List<Event> finalEvents = loadedEvents;
            Exception finalError = loadingError;

            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) {
                    return;
                }

                if (finalError != null) {
                    Toast.makeText(
                            MainActivity.this,
                            "Unable to load events.",
                            Toast.LENGTH_SHORT
                    ).show();
                }

                allEvents = finalEvents == null
                        ? Collections.emptyList()
                        : finalEvents;

                renderEvents();
            });
        });
    }

    private void renderEvents() {
        if (tableEvents == null || textEmptyState == null) {
            return;
        }

        clearEventRows();

        String query = "";

        if (editSearchEvents != null) {
            query = editSearchEvents.getText()
                    .toString()
                    .trim();
        }

        List<Event> displayedEvents =
                EventAlgorithms.filterAndSort(
                        allEvents,
                        query,
                        selectedFilter,
                        selectedSortOption
                );

        if (displayedEvents == null
                || displayedEvents.isEmpty()) {
            showEmptyState(query);
            return;
        }

        textEmptyState.setVisibility(View.GONE);

        for (Event event : displayedEvents) {
            addEventRow(event);
        }
    }

    private void showEmptyState(String query) {
        textEmptyState.setVisibility(View.VISIBLE);

        if (allEvents == null || allEvents.isEmpty()) {
            textEmptyState.setText(
                    "No events have been saved. " +
                            "Select Add Event to create one."
            );
            return;
        }

        boolean hasSearchQuery =
                query != null && !query.trim().isEmpty();

        boolean hasDateFilter =
                selectedFilter
                        != EventFilterOption.ALL_EVENTS;

        if (hasSearchQuery && hasDateFilter) {
            textEmptyState.setText(
                    "No events match your search " +
                            "and selected filter."
            );
        } else if (hasSearchQuery) {
            textEmptyState.setText(
                    "No events match your search."
            );
        } else if (hasDateFilter) {
            textEmptyState.setText(
                    "No events match the selected filter."
            );
        } else {
            textEmptyState.setText(
                    "No events are available."
            );
        }
    }

    private void clearEventRows() {
        int childCount = tableEvents.getChildCount();

        if (childCount > 1) {
            tableEvents.removeViews(
                    1,
                    childCount - 1
            );
        }
    }

    private void addEventRow(Event event) {
        TableRow row = new TableRow(this);
        row.setPadding(4, 4, 4, 4);

        TextView titleView =
                createCell(event.getTitle(), 2.0f);

        TextView dateView =
                createCell(event.getDate(), 1.0f);

        TextView timeView =
                createCell(event.getTime(), 1.0f);

        Button editButton =
                createEditButton(event);

        Button deleteButton =
                createDeleteButton(event);

        row.addView(titleView);
        row.addView(dateView);
        row.addView(timeView);
        row.addView(editButton);
        row.addView(deleteButton);

        row.setOnClickListener(
                view -> showEventDetails(event)
        );

        tableEvents.addView(row);
    }

    private TextView createCell(
            String text,
            float weight
    ) {
        TextView textView = new TextView(this);

        TableRow.LayoutParams parameters =
                new TableRow.LayoutParams(
                        0,
                        TableRow.LayoutParams.WRAP_CONTENT,
                        weight
                );

        textView.setLayoutParams(parameters);
        textView.setText(text == null ? "" : text);
        textView.setPadding(8, 12, 8, 12);
        textView.setGravity(Gravity.CENTER);
        textView.setTextColor(Color.BLACK);

        return textView;
    }

    private Button createEditButton(Event event) {
        Button button = new Button(this);

        button.setText("Edit");
        button.setTextColor(Color.WHITE);
        button.setBackgroundColor(
                Color.rgb(25, 118, 210)
        );

        button.setOnClickListener(view -> {
            Intent intent = new Intent(
                    MainActivity.this,
                    AddEventActivity.class
            );

            intent.putExtra(
                    AddEventActivity.EXTRA_EVENT_ID,
                    (long) event.getId()
            );

            startActivity(intent);
        });

        return button;
    }

    private String getPriorityLabel(int priority) {
        switch (priority) {
            case 2:
                return "High";

            case 1:
                return "Normal";

            case 0:
            default:
                return "Low";
        }
    }

    private Button createDeleteButton(Event event) {
        Button button = new Button(this);

        button.setText("Delete");
        button.setTextColor(Color.WHITE);
        button.setBackgroundColor(
                Color.rgb(198, 40, 40)
        );

        button.setOnClickListener(
                view -> showDeleteConfirmation(event)
        );

        return button;
    }

    private void openAddEventScreen() {
        Intent intent = new Intent(
                MainActivity.this,
                AddEventActivity.class
        );

        startActivity(intent);
    }

    private void openSmsSettingsScreen() {
        Intent intent = new Intent(
                MainActivity.this,
                SmsPermissionActivity.class
        );

        startActivity(intent);
    }

    private void showDeleteConfirmation(Event event) {
        String eventTitle = event.getTitle();

        if (eventTitle == null
                || eventTitle.trim().isEmpty()) {
            eventTitle = "this event";
        } else {
            eventTitle = "\"" + eventTitle + "\"";
        }

        new AlertDialog.Builder(this)
                .setTitle("Delete Event")
                .setMessage(
                        "Are you sure you want to delete "
                                + eventTitle + "?"
                )
                .setPositiveButton(
                        "Delete",
                        (dialog, which) ->
                                deleteEvent(event)
                )
                .setNegativeButton("Cancel", null)
                .show();
    }

    /*
     * Deletes the event on a background thread.
     */
    private void deleteEvent(Event event) {
        databaseExecutor.execute(() -> {
            boolean deleted = false;
            Exception deletionError = null;

            try {
                deleted =
                        eventRepository.deleteEvent(
                                event.getId(),
                                currentUserId
                        );
            } catch (Exception exception) {
                deletionError = exception;
            }

            boolean finalDeleted = deleted;
            Exception finalError = deletionError;

            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) {
                    return;
                }

                if (finalError != null) {
                    Toast.makeText(
                            MainActivity.this,
                            "Unable to delete the event.",
                            Toast.LENGTH_SHORT
                    ).show();
                    return;
                }

                if (!finalDeleted) {
                    Toast.makeText(
                            MainActivity.this,
                            "The event was not deleted.",
                            Toast.LENGTH_SHORT
                    ).show();
                    return;
                }

                Toast.makeText(
                        MainActivity.this,
                        "Event deleted successfully.",
                        Toast.LENGTH_SHORT
                ).show();

                loadEvents();
            });
        });
    }

    private void showEventDetails(Event event) {
        String title = event.getTitle();

        if (title == null || title.trim().isEmpty()) {
            title = "Event Details";
        }

        String date = event.getDate();

        if (date == null || date.trim().isEmpty()) {
            date = "No date provided";
        }

        String time = event.getTime();

        if (time == null || time.trim().isEmpty()) {
            time = "No time provided";
        }

        String description = event.getDescription();

        if (description == null
                || description.trim().isEmpty()) {
            description =
                    "No description was provided.";
        }

        String message =
                "Date: " + date
                        + "\nTime: " + time
                        + "\nPriority: " + getPriorityLabel(event.getPriority())
                        + "\nCompleted: "
                        + (event.isCompleted() ? "Yes" : "No")
                        + "\nRecurrence: "
                        + (event.getRecurrence() == null
                        ? "None"
                        : event.getRecurrence())
                        + "\n\n"
                        + description;

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("Close", null)
                .show();
    }

    private void logout() {
        SessionManager.logout(this);

        Toast.makeText(
                this,
                "Logged out successfully.",
                Toast.LENGTH_SHORT
        ).show();

        redirectToLogin();
    }

    private void redirectToLogin() {
        Intent intent = new Intent(
                MainActivity.this,
                LoginActivity.class
        );

        intent.setFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TASK
        );

        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        databaseExecutor.shutdown();
        super.onDestroy();
    }
}