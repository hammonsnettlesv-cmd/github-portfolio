package com.example.eventtrackerapp.data.repository;

import androidx.annotation.NonNull;

import com.example.eventtrackerapp.data.dao.CategoryDao;
import com.example.eventtrackerapp.data.entity.CategoryEntity;

import java.util.Collections;
import java.util.List;

public class CategoryRepository {

    private final CategoryDao categoryDao;

    public CategoryRepository(
            @NonNull CategoryDao categoryDao
    ) {
        this.categoryDao = categoryDao;
    }

    public long insert(
            @NonNull CategoryEntity category
    ) {
        if (category.userId <= 0L
                || category.name.trim().isEmpty()) {
            return -1L;
        }

        return categoryDao.insert(category);
    }

    @NonNull
    public List<CategoryEntity> getAllForUser(
            long userId
    ) {
        if (userId <= 0L) {
            return Collections.emptyList();
        }

        List<CategoryEntity> categories =
                categoryDao.getAllForUser(userId);

        return categories == null
                ? Collections.emptyList()
                : categories;
    }

    public boolean update(
            long categoryId,
            long userId,
            @NonNull String name,
            String description
    ) {
        if (categoryId <= 0L
                || userId <= 0L
                || name.trim().isEmpty()) {
            return false;
        }

        return categoryDao.updateForUser(
                categoryId,
                userId,
                name.trim(),
                description
        ) == 1;
    }

    public boolean delete(
            long categoryId,
            long userId
    ) {
        if (categoryId <= 0L || userId <= 0L) {
            return false;
        }

        return categoryDao.deleteById(
                categoryId,
                userId
        ) == 1;
    }
}