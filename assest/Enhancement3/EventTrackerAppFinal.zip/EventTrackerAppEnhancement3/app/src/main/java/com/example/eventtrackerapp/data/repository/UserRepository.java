package com.example.eventtrackerapp.data.repository;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.eventtrackerapp.data.dao.UserDao;
import com.example.eventtrackerapp.data.entity.UserEntity;
import com.example.eventtrackerapp.data.security.PasswordHasher;

import java.util.Arrays;
import java.util.Locale;

public class UserRepository {

    private final UserDao userDao;

    public UserRepository(@NonNull UserDao userDao) {
        this.userDao = userDao;
    }

    public long createUser(
            @NonNull String username,
            @NonNull char[] password
    ) {
        String normalizedUsername = normalizeUsername(username);

        if (normalizedUsername.isEmpty()) {
            return -1L;
        }

        try {
            if (userDao.countByUsername(normalizedUsername) > 0) {
                return -1L;
            }

            PasswordHasher.PasswordData passwordData =
                    PasswordHasher.hashPassword(password);

            UserEntity user = new UserEntity();
            user.username = normalizedUsername;
            user.passwordHash = passwordData.getHash();
            user.passwordSalt = passwordData.getSalt();
            user.passwordIterations = passwordData.getIterations();
            user.createdAt = System.currentTimeMillis();

            return userDao.insert(user);
        } finally {
            Arrays.fill(password, '\0');
        }
    }

    @Nullable
    public UserEntity authenticate(
            @NonNull String username,
            @NonNull char[] password
    ) {
        try {
            UserEntity user =
                    userDao.findByUsername(normalizeUsername(username));

            if (user == null) {
                return null;
            }

            boolean valid = PasswordHasher.verifyPassword(
                    password,
                    user.passwordHash,
                    user.passwordSalt,
                    user.passwordIterations
            );

            return valid ? user : null;
        } finally {
            Arrays.fill(password, '\0');
        }
    }

    @NonNull
    private String normalizeUsername(@NonNull String username) {
        return username.trim().toLowerCase(Locale.US);
    }
}