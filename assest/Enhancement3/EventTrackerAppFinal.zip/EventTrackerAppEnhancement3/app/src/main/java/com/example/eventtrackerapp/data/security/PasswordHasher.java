package com.example.eventtrackerapp.data.security;

import android.util.Base64;

import androidx.annotation.NonNull;

import java.security.GeneralSecurityException;
import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public final class PasswordHasher {

    public static final int DEFAULT_ITERATIONS = 120_000;
    private static final int SALT_LENGTH_BYTES = 16;
    private static final int HASH_LENGTH_BITS = 256;

    private PasswordHasher() {
    }

    @NonNull
    public static PasswordData hashPassword(@NonNull char[] password) {
        byte[] salt = new byte[SALT_LENGTH_BYTES];
        new SecureRandom().nextBytes(salt);

        byte[] hash = deriveKey(password, salt, DEFAULT_ITERATIONS);

        return new PasswordData(
                Base64.encodeToString(hash, Base64.NO_WRAP),
                Base64.encodeToString(salt, Base64.NO_WRAP),
                DEFAULT_ITERATIONS
        );
    }

    public static boolean verifyPassword(
            @NonNull char[] candidate,
            @NonNull String storedHash,
            @NonNull String storedSalt,
            int iterations
    ) {
        if (iterations <= 0) {
            return false;
        }

        byte[] salt = Base64.decode(
                storedSalt,
                Base64.NO_WRAP
        );

        byte[] expectedHash = Base64.decode(
                storedHash,
                Base64.NO_WRAP
        );

        byte[] actualHash =
                deriveKey(candidate, salt, iterations);

        try {
            return constantTimeEquals(
                    expectedHash,
                    actualHash
            );
        } finally {
            java.util.Arrays.fill(salt, (byte) 0);
            java.util.Arrays.fill(expectedHash, (byte) 0);
            java.util.Arrays.fill(actualHash, (byte) 0);
        }
    }

    private static byte[] deriveKey(
            char[] password,
            byte[] salt,
            int iterations
    ) {
        PBEKeySpec specification = new PBEKeySpec(
                password,
                salt,
                iterations,
                HASH_LENGTH_BITS
        );

        try {
            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            return factory.generateSecret(specification).getEncoded();
        } catch (GeneralSecurityException exception) {
            throw new IllegalStateException(
                    "Unable to hash password",
                    exception
            );
        } finally {
            specification.clearPassword();
        }
    }

    private static boolean constantTimeEquals(byte[] first, byte[] second) {
        if (first == null || second == null) {
            return false;
        }

        int difference = first.length ^ second.length;
        int length = Math.min(first.length, second.length);

        for (int index = 0; index < length; index++) {
            difference |= first[index] ^ second[index];
        }

        return difference == 0;
    }

    public static final class PasswordData {

        private final String hash;
        private final String salt;
        private final int iterations;

        public PasswordData(
                @NonNull String hash,
                @NonNull String salt,
                int iterations
        ) {
            this.hash = hash;
            this.salt = salt;
            this.iterations = iterations;
        }

        @NonNull
        public String getHash() {
            return hash;
        }

        @NonNull
        public String getSalt() {
            return salt;
        }

        public int getIterations() {
            return iterations;
        }
    }
}