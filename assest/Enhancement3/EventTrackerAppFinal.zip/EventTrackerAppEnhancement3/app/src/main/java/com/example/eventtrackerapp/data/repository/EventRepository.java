package com.example.eventtrackerapp.data.repository;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.eventtrackerapp.Event;
import com.example.eventtrackerapp.data.AppDatabase;
import com.example.eventtrackerapp.data.dao.EventDao;
import com.example.eventtrackerapp.data.entity.EventEntity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EventRepository {

    private final EventDao eventDao;

    public EventRepository(@NonNull Context context) {
        AppDatabase database = AppDatabase.getInstance(
                context.getApplicationContext()
        );
        this.eventDao = database.eventDao();
    }

    public EventRepository(@NonNull EventDao eventDao) {
        this.eventDao = eventDao;
    }

    @Nullable
    public Event getEventById(long eventId, long userId) {
        if (eventId <= 0L || userId <= 0L) {
            return null;
        }

        EventEntity entity = eventDao.getById(eventId, userId);

        if (entity == null) {
            return null;
        }

        return mapEntityToEvent(entity);
    }

    @NonNull
    public List<Event> getAllEvents(long userId) {
        if (userId <= 0L) {
            return Collections.emptyList();
        }

        List<EventEntity> entities = eventDao.getAllForUser(userId);

        if (entities == null || entities.isEmpty()) {
            return Collections.emptyList();
        }

        List<Event> events = new ArrayList<>(entities.size());

        for (EventEntity entity : entities) {
            events.add(mapEntityToEvent(entity));
        }

        return events;
    }

    public long insertEvent(
            @NonNull Event event,
            long userId
    ) {
        if (userId <= 0L) {
            throw new IllegalArgumentException("A valid user ID is required.");
        }

        EventEntity entity = mapEventToEntity(event, userId);
        long now = System.currentTimeMillis();

        entity.id = 0L;
        entity.createdAt = now;
        entity.updatedAt = now;

        long insertedId = eventDao.insert(entity);
        event.setId(insertedId);
        event.setUserId(userId);

        return insertedId;
    }

    public boolean updateEvent(
            @NonNull Event event,
            long userId
    ) {
        if (event.getId() <= 0L || userId <= 0L) {
            return false;
        }

        EventEntity existing = eventDao.getById(
                event.getId(),
                userId
        );

        if (existing == null) {
            return false;
        }

        int affectedRows = eventDao.updateForUser(
                event.getId(),
                userId,
                event.getCategoryId(),
                valueOrEmpty(event.getTitle()),
                valueOrEmpty(event.getDate()),
                valueOrEmpty(event.getTime()),
                nullableDescription(event.getDescription()),
                normalizePriority(event.getPriority()),
                event.isCompleted(),
                normalizeRecurrence(event.getRecurrence()),
                System.currentTimeMillis()
        );

        return affectedRows == 1;
    }

    public boolean deleteEvent(long eventId, long userId) {
        if (eventId <= 0L || userId <= 0L) {
            return false;
        }

        return eventDao.deleteById(eventId, userId) == 1;
    }

    @NonNull
    private Event mapEntityToEvent(@NonNull EventEntity entity) {
        Event event = new Event(
                entity.id,
                entity.categoryId,
                entity.title,
                entity.eventDate,
                entity.eventTime,
                entity.description,
                entity.priority,
                entity.completed,
                entity.recurrence == null
                        ? "NONE"
                        : entity.recurrence
        );

        event.setUserId(entity.userId);
        return event;
    }

    @NonNull
    private EventEntity mapEventToEntity(
            @NonNull Event event,
            long userId
    ) {
        EventEntity entity = new EventEntity();

        entity.id = Math.max(event.getId(), 0L);
        entity.userId = userId;
        entity.categoryId = event.getCategoryId();
        entity.title = valueOrEmpty(event.getTitle());
        entity.eventDate = valueOrEmpty(event.getDate());
        entity.eventTime = valueOrEmpty(event.getTime());
        entity.description = nullableDescription(event.getDescription());
        entity.priority = normalizePriority(event.getPriority());
        entity.completed = event.isCompleted();
        entity.recurrence = normalizeRecurrence(event.getRecurrence());

        return entity;
    }

    private int normalizePriority(int priority) {
        if (priority < Event.PRIORITY_LOW
                || priority > Event.PRIORITY_HIGH) {
            return Event.PRIORITY_NORMAL;
        }

        return priority;
    }

    @NonNull
    private String valueOrEmpty(@Nullable String value) {
        return value == null ? "" : value.trim();
    }

    @Nullable
    private String nullableDescription(@Nullable String value) {
        if (value == null || value.trim().isEmpty()) {
            return null;
        }

        return value.trim();
    }

    @NonNull
    private String normalizeRecurrence(@Nullable String value) {
        if (value == null || value.trim().isEmpty()) {
            return "NONE";
        }

        return value.trim().toUpperCase(java.util.Locale.US);
    }
}