package com.example.eventtrackerapp;

/**
 * Domain model used by activities and business logic.
 */
public class Event {

    public static final int PRIORITY_LOW = 0;
    public static final int PRIORITY_NORMAL = 1;
    public static final int PRIORITY_HIGH = 2;

    private long id;
    private long userId;
    private Long categoryId;
    private String title;
    private String date;
    private String time;
    private String description;
    private int priority;
    private boolean completed;
    private String recurrence;

    public Event(
            String title,
            String date,
            String time,
            String description
    ) {
        this(
                0L,
                null,
                title,
                date,
                time,
                description,
                PRIORITY_NORMAL,
                false,
                "NONE"
        );
    }

    public Event(
            long id,
            String title,
            String date,
            String time,
            String description
    ) {
        this(
                id,
                null,
                title,
                date,
                time,
                description,
                PRIORITY_NORMAL,
                false,
                "NONE"
        );
    }

    public Event(
            long id,
            Long categoryId,
            String title,
            String date,
            String time,
            String description,
            int priority,
            boolean completed,
            String recurrence
    ) {
        this.id = id;
        this.categoryId = categoryId;
        this.title = title;
        this.date = date;
        this.time = time;
        this.description = description;
        this.priority = priority;
        this.completed = completed;
        this.recurrence = recurrence;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public boolean isNew() {
        return id <= 0L;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public String getRecurrence() {
        return recurrence;
    }

    public void setRecurrence(String recurrence) {
        this.recurrence = recurrence;
    }
}