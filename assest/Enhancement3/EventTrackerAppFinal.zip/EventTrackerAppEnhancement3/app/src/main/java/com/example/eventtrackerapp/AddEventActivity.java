package com.example.eventtrackerapp;


import com.example.eventtrackerapp.data.repository.EventRepository;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AddEventActivity extends AppCompatActivity {

    public static final String EXTRA_EVENT_ID = "eventId";
    public static final String EXTRA_USER_ID = "userId";

    private static final long INVALID_ID = -1L;

    private static final String STATE_EVENT_ID = "state_event_id";
    private static final String STATE_USER_ID = "state_user_id";
    private static final String STATE_TITLE = "state_title";
    private static final String STATE_DATE = "state_date";
    private static final String STATE_TIME = "state_time";
    private static final String STATE_DESCRIPTION = "state_description";
    private static final String STATE_CATEGORY_POSITION =
            "state_category_position";
    private static final String STATE_PRIORITY_POSITION =
            "state_priority_position";
    private static final String STATE_RECURRENCE_POSITION =
            "state_recurrence_position";
    private static final String STATE_COMPLETED = "state_completed";

    private TextView textAddEditTitle;

    private EditText editEventTitle;
    private EditText editEventDate;
    private EditText editEventTime;
    private EditText editEventDescription;

    private Spinner spinnerCategory;
    private Spinner spinnerPriority;
    private Spinner spinnerRecurrence;

    private CheckBox checkEventCompleted;

    private Button buttonSaveEvent;
    private Button buttonCancelEvent;

    private EventRepository eventRepository;

    private final ExecutorService databaseExecutor =
            Executors.newSingleThreadExecutor();

    private long currentUserId = INVALID_ID;
    private long eventId = INVALID_ID;

    private boolean databaseOperationInProgress = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_event);

        initializeDependencies();
        initializeViews();
        configureSpinners();
        configureListeners();

        if (savedInstanceState == null) {
            readIntentValues();
            configureScreen();

            if (isEditMode()) {
                loadEventInBackground();
            }
        } else {
            restoreActivityState(savedInstanceState);
            configureScreen();
        }
    }

    /*
     * Creates the repository and session manager.
     * If your EventRepository constructor requires an EventDao instead of a
     * Context, replace the repository initialization with:
     * AppDatabase database = AppDatabase.getInstance(getApplicationContext());
     * eventRepository = new EventRepository(database.eventDao());
     */
    private void initializeDependencies() {
        eventRepository = new EventRepository(getApplicationContext());
    }

    private void initializeViews() {
        textAddEditTitle = findViewById(R.id.textAddEditTitle);

        editEventTitle = findViewById(R.id.editEventTitle);
        editEventDate = findViewById(R.id.editEventDate);
        editEventTime = findViewById(R.id.editEventTime);
        editEventDescription = findViewById(R.id.editEventDescription);

        spinnerCategory = findViewById(R.id.spinnerCategory);
        spinnerPriority = findViewById(R.id.spinnerPriority);
        spinnerRecurrence = findViewById(R.id.spinnerRecurrence);

        checkEventCompleted = findViewById(R.id.checkEventCompleted);

        buttonSaveEvent = findViewById(R.id.buttonSaveEvent);
        buttonCancelEvent = findViewById(R.id.buttonCancelEvent);
    }

    private void configureSpinners() {
        configureCategorySpinner();
        configurePrioritySpinner();
        configureRecurrenceSpinner();
    }

    /**
     * This is an interim category implementation.
     *
     * "No Category" maps to a null category ID. When category management is
     * added, load the categories from CategoryRepository and maintain a list
     * of category IDs corresponding to the spinner positions.
     */
    private void configureCategorySpinner() {
        List<String> categories = Arrays.asList(
                "No Category"
        );

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                categories
        );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerCategory.setAdapter(adapter);
    }

    private void configurePrioritySpinner() {
        List<String> priorities = Arrays.asList(
                "LOW",
                "NORMAL",
                "HIGH"
        );

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                priorities
        );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerPriority.setAdapter(adapter);

        // NORMAL is the default priority.
        setSpinnerSelection(spinnerPriority, "NORMAL");
    }

    private void configureRecurrenceSpinner() {
        List<String> recurrenceOptions = Arrays.asList(
                "NONE",
                "DAILY",
                "WEEKLY",
                "MONTHLY",
                "YEARLY"
        );

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                recurrenceOptions
        );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerRecurrence.setAdapter(adapter);

        // NONE is the default recurrence.
        setSpinnerSelection(spinnerRecurrence, "NONE");
    }

    private void configureListeners() {
        editEventDate.setOnClickListener(view -> showDatePicker());

        editEventTime.setOnClickListener(view -> showTimePicker());

        buttonSaveEvent.setOnClickListener(view -> validateAndSaveEvent());

        buttonCancelEvent.setOnClickListener(view -> cancelAndClose());
    }

    private void readIntentValues() {
        Intent intent = getIntent();

        eventId = readLongExtra(intent, EXTRA_EVENT_ID, INVALID_ID);

        /*
         * The session is the preferred source for the user ID.
         *
         * If your SessionManager method is named differently, replace
         * getUserId() with the corresponding method.
         */
        currentUserId = SessionManager.getUserId(this);

        /*
         * The intent value is only used as a fallback.
         */
        if (currentUserId <= 0L) {
            currentUserId = readLongExtra(
                    intent,
                    EXTRA_USER_ID,
                    INVALID_ID
            );
        }

        if (currentUserId <= 0L) {
            Toast.makeText(
                    this,
                    "No logged-in user was found.",
                    Toast.LENGTH_LONG
            ).show();
            finish();
        }
    }

    /*
     * Safely reads an ID whether the caller stored it as an Integer or Long.
     */
    private long readLongExtra(
            Intent intent,
            String key,
            long defaultValue
    ) {
        if (intent == null || intent.getExtras() == null) {
            return defaultValue;
        }

        Object value = intent.getExtras().get(key);

        if (value instanceof Number) {
            return ((Number) value).longValue();
        }

        return defaultValue;
    }

    private void configureScreen() {
        if (isEditMode()) {
            textAddEditTitle.setText("Edit Event");
            buttonSaveEvent.setText("Update Event");
        } else {
            textAddEditTitle.setText("Add Event");
            buttonSaveEvent.setText("Save Event");
        }
    }

    private boolean isEditMode() {
        return eventId != INVALID_ID;
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    String selectedDate = String.format(
                            Locale.US,
                            "%02d/%02d/%04d",
                            month + 1,
                            dayOfMonth,
                            year
                    );

                    editEventDate.setText(selectedDate);
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );

        datePickerDialog.show();
    }

    private void showTimePicker() {
        Calendar calendar = Calendar.getInstance();

        TimePickerDialog timePickerDialog = new TimePickerDialog(
                this,
                (view, hourOfDay, minute) -> {
                    Calendar selected = Calendar.getInstance();
                    selected.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    selected.set(Calendar.MINUTE, minute);

                    java.text.SimpleDateFormat formatter =
                            new java.text.SimpleDateFormat(
                                    "h:mm a",
                                    Locale.US
                            );

                    editEventTime.setText(
                            formatter.format(selected.getTime())
                    );
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                false
        );

        timePickerDialog.show();
    }

    private void validateAndSaveEvent() {
        if (databaseOperationInProgress) {
            return;
        }

        String title = getTrimmedText(editEventTitle);
        String date = getTrimmedText(editEventDate);
        String time = getTrimmedText(editEventTime);
        String description = getTrimmedText(editEventDescription);

        if (TextUtils.isEmpty(title)) {
            editEventTitle.setError("Event title is required.");
            editEventTitle.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(date)) {
            editEventDate.setError("Event date is required.");
            editEventDate.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(time)) {
            editEventTime.setError("Event time is required.");
            editEventTime.requestFocus();
            return;
        }

        int priority = priorityFromSpinner();

        String recurrence = getSelectedSpinnerValue(
                spinnerRecurrence,
                "NONE"
        );

        boolean completed = checkEventCompleted.isChecked();

        /*
         * Currently the spinner only contains "No Category".
         * Therefore, the category ID is null.
         *
         * This can later be replaced with:
         *
         * Long categoryId =
         *         categoryIds.get(spinnerCategory.getSelectedItemPosition());
         */
        Long categoryId = null;

        Event event;

        if (isEditMode()) {
            event = new Event(
                    (int) eventId,
                    title,
                    date,
                    time,
                    description
            );
        } else {
            event = new Event(
                    title,
                    date,
                    time,
                    description
            );
        }

        event.setCategoryId(categoryId);
        event.setPriority(priority);
        event.setRecurrence(recurrence);
        event.setCompleted(completed);

        saveEventInBackground(event);
    }

    private int priorityFromSpinner() {
        String selected = getSelectedSpinnerValue(
                spinnerPriority,
                "NORMAL"
        );

        switch (selected) {
            case "HIGH":
                return Event.PRIORITY_HIGH;

            case "LOW":
                return Event.PRIORITY_LOW;

            case "NORMAL":
            default:
                return Event.PRIORITY_NORMAL;
        }
    }

    private String getTrimmedText(EditText editText) {
        if (editText.getText() == null) {
            return "";
        }

        return editText.getText().toString().trim();
    }

    private String getSelectedSpinnerValue(
            Spinner spinner,
            String defaultValue
    ) {
        if (spinner.getSelectedItem() == null) {
            return defaultValue;
        }

        String value = spinner.getSelectedItem().toString().trim();

        if (value.isEmpty()) {
            return defaultValue;
        }

        return value.toUpperCase(Locale.US);
    }

    private void saveEventInBackground(Event event) {
        setDatabaseOperationInProgress(true);

        databaseExecutor.execute(() -> {
            try {
                if (isEditMode()) {
                    /*
                     * Expected repository method:
                     *
                     * updateEvent(Event event, long userId)
                     */
                    boolean updated = eventRepository.updateEvent(
                            event,
                            currentUserId
                    );

                    if (!updated) {
                        throw new IllegalStateException(
                                "The event was not found or could not be updated."
                        );
                    }
                } else {
                    /*
                     * Expected repository method:
                     *
                     * insertEvent(Event event, long userId)
                     */
                    long insertedId = eventRepository.insertEvent(
                            event,
                            currentUserId
                    );

                    if (insertedId <= 0L) {
                        throw new IllegalStateException(
                                "The event could not be saved."
                        );
                    }
                }

                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) {
                        return;
                    }

                    setDatabaseOperationInProgress(false);

                    String message = isEditMode()
                            ? "Event updated successfully."
                            : "Event saved successfully.";

                    Toast.makeText(
                            AddEventActivity.this,
                            message,
                            Toast.LENGTH_SHORT
                    ).show();

                    setResult(RESULT_OK);
                    finish();
                });
            } catch (Exception exception) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) {
                        return;
                    }

                    setDatabaseOperationInProgress(false);

                    String errorMessage = exception.getMessage();

                    if (errorMessage == null
                            || errorMessage.trim().isEmpty()) {
                        errorMessage = "Unable to save the event.";
                    }

                    Toast.makeText(
                            AddEventActivity.this,
                            errorMessage,
                            Toast.LENGTH_LONG
                    ).show();
                });
            }
        });
    }

    private void loadEventInBackground() {
        if (!isEditMode() || currentUserId == INVALID_ID) {
            return;
        }

        setDatabaseOperationInProgress(true);

        databaseExecutor.execute(() -> {
            try {
                /*
                 * Expected repository method:
                 *
                 * getEventById(long eventId, long userId)
                 */
                Event event = eventRepository.getEventById(
                        eventId,
                        currentUserId
                );

                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) {
                        return;
                    }

                    setDatabaseOperationInProgress(false);

                    if (event == null) {
                        Toast.makeText(
                                AddEventActivity.this,
                                "The event could not be found.",
                                Toast.LENGTH_LONG
                        ).show();

                        finish();
                        return;
                    }

                    displayEvent(event);
                });
            } catch (Exception exception) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) {
                        return;
                    }

                    setDatabaseOperationInProgress(false);

                    Toast.makeText(
                            AddEventActivity.this,
                            "Unable to load the event.",
                            Toast.LENGTH_LONG
                    ).show();
                });
            }
        });
    }

    private void displayEvent(Event event) {
        editEventTitle.setText(nullToEmpty(event.getTitle()));
        editEventDate.setText(nullToEmpty(event.getDate()));
        editEventTime.setText(nullToEmpty(event.getTime()));
        editEventDescription.setText(
                nullToEmpty(event.getDescription())
        );

        setSpinnerSelection(
                spinnerPriority,
                priorityToSpinnerValue(event.getPriority())
        );

        setSpinnerSelection(
                spinnerRecurrence,
                event.getRecurrence() == null
                        ? "NONE"
                        : event.getRecurrence()
        );

        checkEventCompleted.setChecked(event.isCompleted());

        /*
         * The current category spinner only supports "No Category".
         *
         * When actual categories are loaded, find the spinner position
         * corresponding to event.getCategoryId().
         */
        spinnerCategory.setSelection(0);
    }

    private String priorityToSpinnerValue(int priority) {
        switch (priority) {
            case Event.PRIORITY_HIGH:
                return "HIGH";

            case Event.PRIORITY_LOW:
                return "LOW";

            case Event.PRIORITY_NORMAL:
            default:
                return "NORMAL";
        }
    }

    private String nullToEmpty(String value) {
        return value == null ? "" : value;
    }

    private void setSpinnerSelection(
            Spinner spinner,
            String requestedValue
    ) {
        if (spinner.getAdapter() == null || requestedValue == null) {
            return;
        }

        for (int index = 0;
             index < spinner.getAdapter().getCount();
             index++) {

            Object item = spinner.getAdapter().getItem(index);

            if (item != null
                    && requestedValue.equalsIgnoreCase(
                    item.toString()
            )) {
                spinner.setSelection(index);
                return;
            }
        }
    }

    private void setDatabaseOperationInProgress(boolean inProgress) {
        databaseOperationInProgress = inProgress;

        editEventTitle.setEnabled(!inProgress);
        editEventDate.setEnabled(!inProgress);
        editEventTime.setEnabled(!inProgress);
        editEventDescription.setEnabled(!inProgress);

        spinnerCategory.setEnabled(!inProgress);
        spinnerPriority.setEnabled(!inProgress);
        spinnerRecurrence.setEnabled(!inProgress);

        checkEventCompleted.setEnabled(!inProgress);

        buttonSaveEvent.setEnabled(!inProgress);
        buttonCancelEvent.setEnabled(!inProgress);

        buttonSaveEvent.setText(
                inProgress
                        ? "Please wait..."
                        : isEditMode() ? "Update Event" : "Save Event"
        );
    }

    private void cancelAndClose() {
        if (databaseOperationInProgress) {
            return;
        }

        setResult(RESULT_CANCELED);
        finish();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putLong(STATE_EVENT_ID, eventId);
        outState.putLong(STATE_USER_ID, currentUserId);

        outState.putString(
                STATE_TITLE,
                getTrimmedText(editEventTitle)
        );

        outState.putString(
                STATE_DATE,
                getTrimmedText(editEventDate)
        );

        outState.putString(
                STATE_TIME,
                getTrimmedText(editEventTime)
        );

        outState.putString(
                STATE_DESCRIPTION,
                getTrimmedText(editEventDescription)
        );

        outState.putInt(
                STATE_CATEGORY_POSITION,
                spinnerCategory.getSelectedItemPosition()
        );

        outState.putInt(
                STATE_PRIORITY_POSITION,
                spinnerPriority.getSelectedItemPosition()
        );

        outState.putInt(
                STATE_RECURRENCE_POSITION,
                spinnerRecurrence.getSelectedItemPosition()
        );

        outState.putBoolean(
                STATE_COMPLETED,
                checkEventCompleted.isChecked()
        );
    }

    private void restoreActivityState(Bundle savedInstanceState) {
        eventId = savedInstanceState.getLong(
                STATE_EVENT_ID,
                INVALID_ID
        );

        currentUserId = savedInstanceState.getLong(
                STATE_USER_ID,
                INVALID_ID
        );

        editEventTitle.setText(
                savedInstanceState.getString(STATE_TITLE, "")
        );

        editEventDate.setText(
                savedInstanceState.getString(STATE_DATE, "")
        );

        editEventTime.setText(
                savedInstanceState.getString(STATE_TIME, "")
        );

        editEventDescription.setText(
                savedInstanceState.getString(
                        STATE_DESCRIPTION,
                        ""
                )
        );

        setSpinnerPositionSafely(
                spinnerCategory,
                savedInstanceState.getInt(
                        STATE_CATEGORY_POSITION,
                        0
                )
        );

        setSpinnerPositionSafely(
                spinnerPriority,
                savedInstanceState.getInt(
                        STATE_PRIORITY_POSITION,
                        1
                )
        );

        setSpinnerPositionSafely(
                spinnerRecurrence,
                savedInstanceState.getInt(
                        STATE_RECURRENCE_POSITION,
                        0
                )
        );

        checkEventCompleted.setChecked(
                savedInstanceState.getBoolean(
                        STATE_COMPLETED,
                        false
                )
        );
    }

    private void setSpinnerPositionSafely(
            Spinner spinner,
            int position
    ) {
        if (spinner.getAdapter() == null) {
            return;
        }

        if (position >= 0
                && position < spinner.getAdapter().getCount()) {
            spinner.setSelection(position);
        }
    }

    @Override
    protected void onDestroy() {
        databaseExecutor.shutdown();
        super.onDestroy();
    }
}