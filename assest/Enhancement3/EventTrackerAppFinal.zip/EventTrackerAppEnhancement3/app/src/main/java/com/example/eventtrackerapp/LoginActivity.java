package com.example.eventtrackerapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.eventtrackerapp.data.AppDatabase;
import com.example.eventtrackerapp.data.entity.UserEntity;
import com.example.eventtrackerapp.data.repository.UserRepository;

import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LoginActivity extends Activity {

    private EditText editUsername;
    private EditText editPassword;
    private Button buttonLogin;
    private Button buttonCreateAccount;

    private UserRepository userRepository;

    private final ExecutorService databaseExecutor =
            Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /*
         * If the user already has a valid session, go directly
         * to MainActivity.
         */
        if (SessionManager.isLoggedIn(this)) {
            openMainActivity();
            return;
        }

        setContentView(R.layout.activity_login);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount =
                findViewById(R.id.buttonCreateAccount);

        /*
         * Obtain the application-wide Room database singleton.
         * Do not create or use DatabaseHelper here.
         */
        AppDatabase database =
                AppDatabase.getInstance(getApplicationContext());

        userRepository =
                new UserRepository(database.userDao());

        buttonLogin.setOnClickListener(
                view -> loginUser()
        );

        buttonCreateAccount.setOnClickListener(
                view -> createAccount()
        );
    }

    /*
     * Authenticates a user on the background executor.
     */
    private void loginUser() {
        String username = editUsername.getText()
                .toString()
                .trim();

        char[] password = editPassword.getText()
                .toString()
                .toCharArray();

        if (username.isEmpty() || password.length == 0) {
            Arrays.fill(password, '\0');

            Toast.makeText(
                    this,
                    "Please enter both username and password.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        setButtonsEnabled(false);

        databaseExecutor.execute(() -> {
            UserEntity user = null;
            Exception authenticationError = null;

            try {
                user = userRepository.authenticate(
                        username,
                        password
                );
            } catch (Exception exception) {
                authenticationError = exception;
            } finally {
                /*
                 * Reduce the amount of time the password remains
                 * available in memory.
                 */
                Arrays.fill(password, '\0');
            }

            UserEntity authenticatedUser = user;
            Exception finalError = authenticationError;

            runOnUiThread(() -> {
                editPassword.setText("");
                setButtonsEnabled(true);

                if (finalError != null) {
                    Toast.makeText(
                            LoginActivity.this,
                            "Unable to complete login.",
                            Toast.LENGTH_SHORT
                    ).show();

                    return;
                }

                if (authenticatedUser == null) {
                    Toast.makeText(
                            LoginActivity.this,
                            "Invalid username or password.",
                            Toast.LENGTH_SHORT
                    ).show();

                    return;
                }

                /*
                 * Store both the user ID and username so that
                 * event operations can be scoped to this user.
                 */
                SessionManager.saveLoginSession(
                        LoginActivity.this,
                        authenticatedUser.id,
                        authenticatedUser.username
                );

                Toast.makeText(
                        LoginActivity.this,
                        "Login successful.",
                        Toast.LENGTH_SHORT
                ).show();

                openMainActivity();
            });
        });
    }

    /*
     * Creates a new user account on the background executor.
     */
    private void createAccount() {
        String username = editUsername.getText()
                .toString()
                .trim();

        char[] password = editPassword.getText()
                .toString()
                .toCharArray();

        if (username.isEmpty() || password.length == 0) {
            Arrays.fill(password, '\0');

            Toast.makeText(
                    this,
                    "Please enter both username and password.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        setButtonsEnabled(false);

        databaseExecutor.execute(() -> {
            long userId = -1L;
            Exception creationError = null;

            try {
                userId = userRepository.createUser(
                        username,
                        password
                );
            } catch (Exception exception) {
                creationError = exception;
            } finally {
                /*
                 * Remove the original password characters from
                 * this temporary array.
                 */
                Arrays.fill(password, '\0');
            }

            long createdUserId = userId;
            Exception finalError = creationError;

            runOnUiThread(() -> {
                editPassword.setText("");
                setButtonsEnabled(true);

                if (finalError != null || createdUserId <= 0) {
                    Toast.makeText(
                            LoginActivity.this,
                            "The account could not be created. "
                                    + "The username may already exist.",
                            Toast.LENGTH_SHORT
                    ).show();

                    return;
                }

                Toast.makeText(
                        LoginActivity.this,
                        "New account created. You may now log in.",
                        Toast.LENGTH_SHORT
                ).show();
            });
        });
    }

    /*
     * Prevents users from starting several database operations
     * by repeatedly pressing the buttons.
     */
    private void setButtonsEnabled(boolean enabled) {
        buttonLogin.setEnabled(enabled);
        buttonCreateAccount.setEnabled(enabled);
    }

    /*
     * Opens MainActivity and removes LoginActivity from the
     * back stack.
     */
    private void openMainActivity() {
        Intent intent = new Intent(
                LoginActivity.this,
                MainActivity.class
        );

        intent.setFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TASK
        );

        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        databaseExecutor.shutdown();
        super.onDestroy();
    }
}