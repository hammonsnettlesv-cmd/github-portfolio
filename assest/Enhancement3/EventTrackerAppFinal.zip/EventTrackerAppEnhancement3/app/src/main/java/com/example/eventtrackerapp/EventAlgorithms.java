package com.example.eventtrackerapp;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.IdentityHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/*
 * Contains the searching, filtering, and sorting algorithms used by the app.
 */
public final class EventAlgorithms {

    private static final String DATE_TIME_PATTERN = "MM/dd/yyyy h:mm a";

    private EventAlgorithms() {
        // Utility class; prevent instantiation.
    }

    /*
     * Compatibility overload. Existing calls default to All Events.
     */
    public static List<Event> filterAndSort(
            List<Event> source,
            String query,
            EventSortOption sortOption
    ) {
        return filterAndSort(
                source,
                query,
                EventFilterOption.ALL_EVENTS,
                sortOption
        );
    }

    /*
     * Searches, date-filters, and sorts the supplied events.
     */
    public static List<Event> filterAndSort(
            List<Event> source,
            String query,
            EventFilterOption filterOption,
            EventSortOption sortOption
    ) {
        return filterAndSort(
                source,
                query,
                filterOption,
                sortOption,
                Calendar.getInstance()
        );
    }

    /*
     * Package-visible overload that accepts a fixed current time.
     * Supplying the time makes Today, Upcoming, and Past behavior
     * deterministic during unit testing.
     */
    static List<Event> filterAndSort(
            List<Event> source,
            String query,
            EventFilterOption filterOption,
            EventSortOption sortOption,
            Calendar now
    ) {
        List<Event> results = new ArrayList<>();

        if (source == null || source.isEmpty()) {
            return results;
        }

        EventFilterOption effectiveFilter =
                filterOption == null
                        ? EventFilterOption.ALL_EVENTS
                        : filterOption;

        EventSortOption effectiveSort =
                sortOption == null
                        ? EventSortOption.DATE_ASCENDING
                        : sortOption;

        Calendar effectiveNow =
                now == null ? Calendar.getInstance() : (Calendar) now.clone();

        Set<String> queryTerms = normalizeQuery(query);

        /*
         * IdentityHashMap associates a parsed date with the exact Event
         * object rather than relying on Event.equals().
         *
         * Parsing each event once avoids repeated date conversions during
         * merge sort comparisons.
         */
        Map<Event, Date> parsedDateCache = new IdentityHashMap<>();

        for (Event event : source) {
            if (event == null) {
                continue;
            }

            Date eventDateTime = parseDateTime(event);
            parsedDateCache.put(event, eventDateTime);

            if (!matchesSearch(event, queryTerms)) {
                continue;
            }

            if (!matchesDateFilter(
                    eventDateTime,
                    effectiveFilter,
                    effectiveNow
            )) {
                continue;
            }

            results.add(event);
        }

        return mergeSort(results, effectiveSort, parsedDateCache);
    }

    /*
     * Determines whether an event belongs in the selected date category.
     */
    private static boolean matchesDateFilter(
            Date eventDateTime,
            EventFilterOption filterOption,
            Calendar now
    ) {
        if (filterOption == EventFilterOption.ALL_EVENTS) {
            return true;
        }

        // Invalid date/time values cannot be classified chronologically.
        if (eventDateTime == null) {
            return false;
        }

        switch (filterOption) {
            case TODAY:
                Calendar eventCalendar = Calendar.getInstance();
                eventCalendar.setTime(eventDateTime);

                return eventCalendar.get(Calendar.ERA)
                        == now.get(Calendar.ERA)
                        && eventCalendar.get(Calendar.YEAR)
                        == now.get(Calendar.YEAR)
                        && eventCalendar.get(Calendar.DAY_OF_YEAR)
                        == now.get(Calendar.DAY_OF_YEAR);

            case UPCOMING:
                // An event exactly at the current time is considered upcoming.
                return !eventDateTime.before(now.getTime());

            case PAST:
                return eventDateTime.before(now.getTime());

            case ALL_EVENTS:
            default:
                return true;
        }
    }

    private static Set<String> normalizeQuery(String query) {
        Set<String> terms = new LinkedHashSet<>();

        if (query == null || query.trim().isEmpty()) {
            return terms;
        }

        String[] pieces = query
                .trim()
                .toLowerCase(Locale.US)
                .split("\\s+");

        for (String piece : pieces) {
            if (!piece.isEmpty()) {
                terms.add(piece);
            }
        }

        return terms;
    }

    /*
     * Uses AND matching: every query term must occur somewhere in the
     * searchable event text.
     */
    private static boolean matchesSearch(
            Event event,
            Set<String> queryTerms
    ) {
        if (queryTerms.isEmpty()) {
            return true;
        }

        String searchableText =
                safe(event.getTitle()) + " "
                        + safe(event.getDate()) + " "
                        + safe(event.getTime()) + " "
                        + safe(event.getDescription());

        searchableText = searchableText.toLowerCase(Locale.US);

        for (String term : queryTerms) {
            if (!searchableText.contains(term)) {
                return false;
            }
        }

        return true;
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }

    private static Date parseDateTime(Event event) {
        String combinedDateTime =
                safe(event.getDate()).trim()
                        + " "
                        + safe(event.getTime()).trim();

        SimpleDateFormat formatter =
                new SimpleDateFormat(DATE_TIME_PATTERN, Locale.US);

        // Prevent values such as 02/30/2026 from being silently corrected.
        formatter.setLenient(false);

        try {
            return formatter.parse(combinedDateTime);
        } catch (ParseException exception) {
            return null;
        }
    }

    private static List<Event> mergeSort(
            List<Event> events,
            EventSortOption sortOption,
            Map<Event, Date> parsedDateCache
    ) {
        if (events.size() <= 1) {
            return new ArrayList<>(events);
        }

        int middle = events.size() / 2;

        List<Event> left = mergeSort(
                events.subList(0, middle),
                sortOption,
                parsedDateCache
        );

        List<Event> right = mergeSort(
                events.subList(middle, events.size()),
                sortOption,
                parsedDateCache
        );

        return merge(left, right, sortOption, parsedDateCache);
    }

    private static List<Event> merge(
            List<Event> left,
            List<Event> right,
            EventSortOption sortOption,
            Map<Event, Date> parsedDateCache
    ) {
        List<Event> merged =
                new ArrayList<>(left.size() + right.size());

        int leftIndex = 0;
        int rightIndex = 0;

        while (leftIndex < left.size()
                && rightIndex < right.size()) {

            Event leftEvent = left.get(leftIndex);
            Event rightEvent = right.get(rightIndex);

            int comparison = compareEvents(
                    leftEvent,
                    rightEvent,
                    sortOption,
                    parsedDateCache
            );

            /*
             * Taking from the left when values are equal preserves the
             * stability of merge sort.
             */
            if (comparison <= 0) {
                merged.add(leftEvent);
                leftIndex++;
            } else {
                merged.add(rightEvent);
                rightIndex++;
            }
        }

        while (leftIndex < left.size()) {
            merged.add(left.get(leftIndex++));
        }

        while (rightIndex < right.size()) {
            merged.add(right.get(rightIndex++));
        }

        return merged;
    }

    private static int compareEvents(
            Event first,
            Event second,
            EventSortOption sortOption,
            Map<Event, Date> parsedDateCache
    ) {
        switch (sortOption) {
            case DATE_DESCENDING:
                return compareDates(
                        parsedDateCache.get(first),
                        parsedDateCache.get(second),
                        true
                );

            case TITLE_ASCENDING:
                return compareTitles(first, second, false);

            case TITLE_DESCENDING:
                return compareTitles(first, second, true);

            case DATE_ASCENDING:
            default:
                return compareDates(
                        parsedDateCache.get(first),
                        parsedDateCache.get(second),
                        false
                );
        }
    }

    private static int compareDates(
            Date firstDate,
            Date secondDate,
            boolean descending
    ) {
        /*
         * Invalid dates remain at the end in both directions so malformed
         * data does not appear before valid events.
         */
        if (firstDate == null && secondDate == null) {
            return 0;
        }

        if (firstDate == null) {
            return 1;
        }

        if (secondDate == null) {
            return -1;
        }

        int comparison = firstDate.compareTo(secondDate);
        return descending ? -comparison : comparison;
    }

    private static int compareTitles(
            Event first,
            Event second,
            boolean descending
    ) {
        String firstTitle = safe(first.getTitle());
        String secondTitle = safe(second.getTitle());

        int comparison =
                firstTitle.compareToIgnoreCase(secondTitle);

        return descending ? -comparison : comparison;
    }
}