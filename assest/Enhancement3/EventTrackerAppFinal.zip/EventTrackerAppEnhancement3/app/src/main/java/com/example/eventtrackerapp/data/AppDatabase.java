package com.example.eventtrackerapp.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.eventtrackerapp.data.dao.CategoryDao;
import com.example.eventtrackerapp.data.dao.EventDao;
import com.example.eventtrackerapp.data.dao.UserDao;
import com.example.eventtrackerapp.data.entity.CategoryEntity;
import com.example.eventtrackerapp.data.entity.EventEntity;
import com.example.eventtrackerapp.data.entity.UserEntity;
import com.example.eventtrackerapp.data.security.PasswordHasher;

@Database(
        entities = {
                UserEntity.class,
                EventEntity.class,
                CategoryEntity.class
        },
        version = 3,
        exportSchema = true
)
public abstract class AppDatabase extends RoomDatabase {

    private static final String DATABASE_NAME = "EventTracker.db";

    private static volatile AppDatabase INSTANCE;

    public abstract UserDao userDao();

    public abstract EventDao eventDao();

    public abstract CategoryDao categoryDao();

    public static final Migration MIGRATION_2_3 =
            new Migration(2, 3) {
                @Override
                public void migrate(
                        @NonNull SupportSQLiteDatabase database
                ) {
                    final long migrationTime = System.currentTimeMillis();

                    if (tableExists(database, "users")) {
                        database.execSQL(
                                "ALTER TABLE `users` " +
                                        "RENAME TO `users_legacy`"
                        );
                    }

                    if (tableExists(database, "events")) {
                        database.execSQL(
                                "ALTER TABLE `events` " +
                                        "RENAME TO `events_legacy`"
                        );
                    }

                    createVersionThreeTables(database);

                    /*
                     * Convert plaintext passwords into independently salted
                     * PBKDF2 hashes while preserving user IDs.
                     */
                    migrateUsers(database, migrationTime);

                    /*
                     * Legacy events did not contain a user foreign key.
                     * Assign them to the first migrated user.
                     */
                    long ownerId = findFirstUserId(database);

                    if (ownerId == -1
                            && tableExists(database, "events_legacy")
                            && tableHasRows(database, "events_legacy")) {
                        ownerId = createLegacyOwner(
                                database,
                                migrationTime
                        );
                    }

                    if (ownerId != -1) {
                        migrateEvents(
                                database,
                                ownerId,
                                migrationTime
                        );
                    }

                    createVersionThreeIndexes(database);

                    /*
                     * The plaintext password data must not remain in an
                     * accessible legacy table after successful copy
                     * These are temporary migration tables, not destructive
                     * onUpgrade logic. Their records have already been copied.
                     */
                    database.execSQL(
                            "DROP TABLE IF EXISTS `events_legacy`"
                    );
                    database.execSQL(
                            "DROP TABLE IF EXISTS `users_legacy`"
                    );
                }
            };

    private static void createVersionThreeTables(
            SupportSQLiteDatabase database
    ) {
        database.execSQL(
                "CREATE TABLE IF NOT EXISTS `users` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`username` TEXT NOT NULL, " +
                        "`password_hash` TEXT NOT NULL, " +
                        "`password_salt` TEXT NOT NULL, " +
                        "`password_iterations` INTEGER NOT NULL, " +
                        "`created_at` INTEGER NOT NULL" +
                        ")"
        );

        database.execSQL(
                "CREATE TABLE IF NOT EXISTS `categories` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`user_id` INTEGER NOT NULL, " +
                        "`name` TEXT NOT NULL, " +
                        "`description` TEXT, " +
                        "`created_at` INTEGER NOT NULL, " +
                        "FOREIGN KEY(`user_id`) REFERENCES `users`(`id`) " +
                        "ON UPDATE NO ACTION ON DELETE CASCADE" +
                        ")"
        );

        database.execSQL(
                "CREATE TABLE IF NOT EXISTS `events` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`user_id` INTEGER NOT NULL, " +
                        "`category_id` INTEGER, " +
                        "`title` TEXT NOT NULL, " +
                        "`event_date` TEXT NOT NULL, " +
                        "`event_time` TEXT NOT NULL, " +
                        "`description` TEXT, " +
                        "`priority` INTEGER NOT NULL, " +
                        "`completed` INTEGER NOT NULL, " +
                        "`recurrence` TEXT, " +
                        "`created_at` INTEGER NOT NULL, " +
                        "`updated_at` INTEGER NOT NULL, " +
                        "FOREIGN KEY(`user_id`) REFERENCES `users`(`id`) " +
                        "ON UPDATE NO ACTION ON DELETE CASCADE, " +
                        "FOREIGN KEY(`category_id`) " +
                        "REFERENCES `categories`(`id`) " +
                        "ON UPDATE NO ACTION ON DELETE SET NULL" +
                        ")"
        );
    }

    private static void createVersionThreeIndexes(
            SupportSQLiteDatabase database
    ) {
        database.execSQL(
                "CREATE UNIQUE INDEX IF NOT EXISTS " +
                        "`index_users_username` " +
                        "ON `users` (`username`)"
        );

        database.execSQL(
                "CREATE INDEX IF NOT EXISTS " +
                        "`index_categories_user_id` " +
                        "ON `categories` (`user_id`)"
        );

        database.execSQL(
                "CREATE UNIQUE INDEX IF NOT EXISTS " +
                        "`index_categories_user_id_name` " +
                        "ON `categories` (`user_id`, `name`)"
        );

        database.execSQL(
                "CREATE INDEX IF NOT EXISTS " +
                        "`index_events_user_id` " +
                        "ON `events` (`user_id`)"
        );

        database.execSQL(
                "CREATE INDEX IF NOT EXISTS " +
                        "`index_events_category_id` " +
                        "ON `events` (`category_id`)"
        );

        database.execSQL(
                "CREATE INDEX IF NOT EXISTS " +
                        "`index_events_user_id_event_date_event_time` " +
                        "ON `events` (`user_id`, `event_date`, `event_time`)"
        );
    }

    private static void migrateUsers(
            SupportSQLiteDatabase database,
            long migrationTime
    ) {
        if (!tableExists(database, "users_legacy")) {
            return;
        }

        try (Cursor cursor = database.query(
                "SELECT * FROM `users_legacy`"
        )) {
            while (cursor.moveToNext()) {
                long id = getLong(
                        cursor,
                        0L,
                        "id",
                        "_id",
                        "user_id"
                );

                String username = getString(
                        cursor,
                        "",
                        "username",
                        "user_name"
                );

                String plaintextPassword = getString(
                        cursor,
                        "",
                        "password",
                        "user_password"
                );

                if (username.trim().isEmpty()) {
                    username = "legacy_user_" + id;
                }

                PasswordHasher.PasswordData passwordData =
                        PasswordHasher.hashPassword(
                                plaintextPassword.toCharArray()
                        );

                ContentValues values = new ContentValues();

                if (id > 0) {
                    values.put("id", id);
                }

                values.put("username", username);
                values.put(
                        "password_hash",
                        passwordData.getHash()
                );
                values.put(
                        "password_salt",
                        passwordData.getSalt()
                );
                values.put(
                        "password_iterations",
                        passwordData.getIterations()
                );
                values.put("created_at", migrationTime);

                database.insert(
                        "users",
                        SQLiteDatabase.CONFLICT_ABORT,
                        values
                );
            }
        }
    }

    private static void migrateEvents(
            SupportSQLiteDatabase database,
            long ownerId,
            long migrationTime
    ) {
        if (!tableExists(database, "events_legacy")) {
            return;
        }

        try (Cursor cursor = database.query(
                "SELECT * FROM `events_legacy`"
        )) {
            while (cursor.moveToNext()) {
                long eventId = getLong(
                        cursor,
                        0L,
                        "id",
                        "_id",
                        "event_id"
                );

                String title = getString(
                        cursor,
                        "Untitled event",
                        "title",
                        "event_title",
                        "event_name",
                        "name"
                );

                String date = getString(
                        cursor,
                        "",
                        "event_date",
                        "date"
                );

                String time = getString(
                        cursor,
                        "",
                        "event_time",
                        "time"
                );

                String description = getNullableString(
                        cursor,
                        "description",
                        "event_description"
                );

                ContentValues values = new ContentValues();

                if (eventId > 0) {
                    values.put("id", eventId);
                }

                values.put("user_id", ownerId);
                values.putNull("category_id");
                values.put("title", title);
                values.put("event_date", date);
                values.put("event_time", time);

                if (description == null) {
                    values.putNull("description");
                } else {
                    values.put("description", description);
                }

                values.put("priority", 0);
                values.put("completed", 0);
                values.putNull("recurrence");
                values.put("created_at", migrationTime);
                values.put("updated_at", migrationTime);

                database.insert(
                        "events",
                        SQLiteDatabase.CONFLICT_ABORT,
                        values
                );
            }
        }
    }

    private static long findFirstUserId(
            SupportSQLiteDatabase database
    ) {
        try (Cursor cursor = database.query(
                "SELECT `id` FROM `users` " +
                        "ORDER BY `id` ASC LIMIT 1"
        )) {
            if (cursor.moveToFirst()) {
                return cursor.getLong(0);
            }
        }

        return -1;
    }

    private static long createLegacyOwner(
            SupportSQLiteDatabase database,
            long migrationTime
    ) {
        /*
         * Generate a random password hash. The account is only used to
         * maintain foreign-key ownership for orphaned legacy events.
         */
        PasswordHasher.PasswordData passwordData =
                PasswordHasher.hashPassword(
                        Long.toHexString(
                                new java.security.SecureRandom().nextLong()
                        ).toCharArray()
                );

        ContentValues values = new ContentValues();
        values.put("username", "__legacy_event_owner__");
        values.put("password_hash", passwordData.getHash());
        values.put("password_salt", passwordData.getSalt());
        values.put(
                "password_iterations",
                passwordData.getIterations()
        );
        values.put("created_at", migrationTime);

        return database.insert(
                "users",
                SQLiteDatabase.CONFLICT_ABORT,
                values
        );
    }

    private static boolean tableExists(
            SupportSQLiteDatabase database,
            String tableName
    ) {
        try (Cursor cursor = database.query(
                "SELECT 1 FROM `sqlite_master` " +
                        "WHERE `type` = 'table' AND `name` = ? LIMIT 1",
                new Object[]{tableName}
        )) {
            return cursor.moveToFirst();
        }
    }

    private static boolean tableHasRows(
            SupportSQLiteDatabase database,
            String tableName
    ) {
        /*
         * tableName is only supplied internally from a fixed table name.
         */
        try (Cursor cursor = database.query(
                "SELECT 1 FROM `" + tableName + "` LIMIT 1"
        )) {
            return cursor.moveToFirst();
        }
    }

    private static long getLong(
            Cursor cursor,
            long defaultValue,
            String... possibleNames
    ) {
        int index = findColumn(cursor, possibleNames);

        if (index < 0 || cursor.isNull(index)) {
            return defaultValue;
        }

        return cursor.getLong(index);
    }

    @NonNull
    private static String getString(
            Cursor cursor,
            @NonNull String defaultValue,
            String... possibleNames
    ) {
        int index = findColumn(cursor, possibleNames);

        if (index < 0 || cursor.isNull(index)) {
            return defaultValue;
        }

        String value = cursor.getString(index);
        return value == null ? defaultValue : value;
    }

    @Nullable
    private static String getNullableString(
            Cursor cursor,
            String... possibleNames
    ) {
        int index = findColumn(cursor, possibleNames);

        if (index < 0 || cursor.isNull(index)) {
            return null;
        }

        return cursor.getString(index);
    }

    private static int findColumn(
            Cursor cursor,
            String... possibleNames
    ) {
        for (String name : possibleNames) {
            int index = cursor.getColumnIndex(name);

            if (index >= 0) {
                return index;
            }
        }

        return -1;
    }

    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    DATABASE_NAME
                            )
                            .addMigrations(MIGRATION_2_3)
                            .build();
                }
            }
        }

        return INSTANCE;
    }
}