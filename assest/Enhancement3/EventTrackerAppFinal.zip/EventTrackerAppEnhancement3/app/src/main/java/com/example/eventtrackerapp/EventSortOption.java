package com.example.eventtrackerapp;

/*
 * Defines the sorting options available on the event dashboard.
 */
public enum EventSortOption {
    DATE_ASCENDING("Date: Earliest First"),
    DATE_DESCENDING("Date: Latest First"),
    TITLE_ASCENDING("Title: A to Z"),
    TITLE_DESCENDING("Title: Z to A");

    private final String displayName;

    EventSortOption(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}