package com.example.eventtrackerapp.data.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.eventtrackerapp.data.entity.EventEntity;

import java.util.List;

@Dao
public interface EventDao {

    @Insert(onConflict = OnConflictStrategy.ABORT)
    long insert(EventEntity event);

    @Query(
            "UPDATE events SET " +
                    "category_id = :categoryId, " +
                    "title = :title, " +
                    "event_date = :eventDate, " +
                    "event_time = :eventTime, " +
                    "description = :description, " +
                    "priority = :priority, " +
                    "completed = :completed, " +
                    "recurrence = :recurrence, " +
                    "updated_at = :updatedAt " +
                    "WHERE id = :eventId AND user_id = :userId"
    )
    int updateForUser(
            long eventId,
            long userId,
            Long categoryId,
            String title,
            String eventDate,
            String eventTime,
            String description,
            int priority,
            boolean completed,
            String recurrence,
            long updatedAt
    );

    @Query(
            "SELECT * FROM events " +
                    "WHERE user_id = :userId " +
                    "ORDER BY event_date ASC, event_time ASC"
    )
    List<EventEntity> getAllForUser(long userId);

    @Query(
            "SELECT * FROM events " +
                    "WHERE id = :eventId AND user_id = :userId " +
                    "LIMIT 1"
    )
    EventEntity getById(long eventId, long userId);

    @Query(
            "DELETE FROM events " +
                    "WHERE id = :eventId AND user_id = :userId"
    )
    int deleteById(long eventId, long userId);

    @Query(
            "SELECT * FROM events " +
                    "WHERE user_id = :userId AND completed = 0 " +
                    "ORDER BY event_date ASC, event_time ASC"
    )
    List<EventEntity> getIncompleteForUser(long userId);
}