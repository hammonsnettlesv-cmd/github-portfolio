package com.example.eventtrackerapp;

/*
 * Defines the date-based filtering options available to the user.
 */
public enum EventFilterOption {
    ALL_EVENTS("All Events"),
    TODAY("Today"),
    UPCOMING("Upcoming"),
    PAST("Past");

    private final String displayName;

    EventFilterOption(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}