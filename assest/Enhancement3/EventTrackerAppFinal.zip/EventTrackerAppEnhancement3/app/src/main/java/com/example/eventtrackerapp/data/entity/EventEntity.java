package com.example.eventtrackerapp.data.entity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "events",
        foreignKeys = {
                @ForeignKey(
                        entity = UserEntity.class,
                        parentColumns = "id",
                        childColumns = "user_id",
                        onDelete = ForeignKey.CASCADE
                ),
                @ForeignKey(
                        entity = CategoryEntity.class,
                        parentColumns = "id",
                        childColumns = "category_id",
                        onDelete = ForeignKey.SET_NULL
                )
        },
        indices = {
                @Index(value = {"user_id"}),
                @Index(value = {"category_id"}),
                @Index(value = {"user_id", "event_date", "event_time"})
        }
)
public class EventEntity {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    public long id;

    @ColumnInfo(name = "user_id")
    public long userId;

    @Nullable
    @ColumnInfo(name = "category_id")
    public Long categoryId;

    @NonNull
    @ColumnInfo(name = "title")
    public String title;

    @NonNull
    @ColumnInfo(name = "event_date")
    public String eventDate;

    @NonNull
    @ColumnInfo(name = "event_time")
    public String eventTime;

    @Nullable
    @ColumnInfo(name = "description")
    public String description;

    @ColumnInfo(name = "priority")
    public int priority;

    @ColumnInfo(name = "completed")
    public boolean completed;

    @Nullable
    @ColumnInfo(name = "recurrence")
    public String recurrence;

    @ColumnInfo(name = "created_at")
    public long createdAt;

    @ColumnInfo(name = "updated_at")
    public long updatedAt;
}