package com.example.eventtrackerapp.data.entity;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "users",
        indices = {
                @Index(value = {"username"}, unique = true)
        }
)
public class UserEntity {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    public long id;

    @NonNull
    @ColumnInfo(name = "username")
    public String username;

    @NonNull
    @ColumnInfo(name = "password_hash")
    public String passwordHash;

    @NonNull
    @ColumnInfo(name = "password_salt")
    public String passwordSalt;

    @ColumnInfo(name = "password_iterations")
    public int passwordIterations;

    @ColumnInfo(name = "created_at")
    public long createdAt;
}