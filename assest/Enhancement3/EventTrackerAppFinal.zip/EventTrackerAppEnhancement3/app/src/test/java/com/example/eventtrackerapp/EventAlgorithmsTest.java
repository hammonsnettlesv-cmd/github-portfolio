package com.example.eventtrackerapp;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

public class EventAlgorithmsTest {

    private List<Event> events;
    private Calendar fixedNow;

    private Event pastEvent;
    private Event todayMorningEvent;
    private Event todayAfternoonEvent;
    private Event upcomingEvent;
    private Event invalidDateEvent;

    @Before
    public void setUp() {
        /*
         * A fixed current time makes the date-filter tests deterministic.
         *
         * Current time:
         * January 15, 2026 at 12:00 PM
         */
        fixedNow = Calendar.getInstance();
        fixedNow.clear();
        fixedNow.set(
                2026,
                Calendar.JANUARY,
                15,
                12,
                0,
                0
        );

        pastEvent = createEvent(
                "Dentist Appointment",
                "01/14/2026",
                "9:00 AM",
                "Routine dental cleaning"
        );

        todayMorningEvent = createEvent(
                "Morning Meeting",
                "01/15/2026",
                "9:00 AM",
                "Discuss the project schedule"
        );

        todayAfternoonEvent = createEvent(
                "Afternoon Workshop",
                "01/15/2026",
                "3:00 PM",
                "Java algorithms workshop"
        );

        upcomingEvent = createEvent(
                "Conference",
                "01/16/2026",
                "8:00 AM",
                "Software engineering conference"
        );

        invalidDateEvent = createEvent(
                "Invalid Event",
                "02/30/2026",
                "10:00 AM",
                "Event with an invalid date"
        );

        /*
         * Deliberately placed in a nonchronological order so sorting can
         * be verified.
         */
        events = new ArrayList<>(Arrays.asList(
                upcomingEvent,
                invalidDateEvent,
                todayAfternoonEvent,
                pastEvent,
                todayMorningEvent
        ));
    }

    // ---------------------------------------------------------------------
    // Date sorting tests
    // ---------------------------------------------------------------------

    @Test
    public void dateAscending_sortsEventsChronologically() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(5, results.size());

        assertSame(pastEvent, results.get(0));
        assertSame(todayMorningEvent, results.get(1));
        assertSame(todayAfternoonEvent, results.get(2));
        assertSame(upcomingEvent, results.get(3));

        // Invalid dates remain at the end.
        assertSame(invalidDateEvent, results.get(4));
    }

    @Test
    public void dateDescending_sortsEventsReverseChronologically() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_DESCENDING,
                fixedNow
        );

        assertEquals(5, results.size());

        assertSame(upcomingEvent, results.get(0));
        assertSame(todayAfternoonEvent, results.get(1));
        assertSame(todayMorningEvent, results.get(2));
        assertSame(pastEvent, results.get(3));

        // Invalid dates remain at the end in descending order too.
        assertSame(invalidDateEvent, results.get(4));
    }

    @Test
    public void dateAscending_usesTimeWhenDatesAreEqual() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "",
                EventFilterOption.TODAY,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(2, results.size());
        assertSame(todayMorningEvent, results.get(0));
        assertSame(todayAfternoonEvent, results.get(1));
    }

    @Test
    public void mergeSort_isStableWhenDateAndTimeAreEqual() {
        Event first = createEvent(
                "First Event",
                "01/20/2026",
                "10:00 AM",
                "First matching date"
        );

        Event second = createEvent(
                "Second Event",
                "01/20/2026",
                "10:00 AM",
                "Second matching date"
        );

        Event third = createEvent(
                "Third Event",
                "01/20/2026",
                "10:00 AM",
                "Third matching date"
        );

        List<Event> equalDateEvents = Arrays.asList(
                first,
                second,
                third
        );

        List<Event> results = EventAlgorithms.filterAndSort(
                equalDateEvents,
                "",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(3, results.size());

        /*
         * Stable sorting preserves the original order when comparison
         * values are equal.
         */
        assertSame(first, results.get(0));
        assertSame(second, results.get(1));
        assertSame(third, results.get(2));
    }

    // ---------------------------------------------------------------------
    // Title sorting tests
    // ---------------------------------------------------------------------

    @Test
    public void titleAscending_sortsTitlesAlphabetically() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.TITLE_ASCENDING,
                fixedNow
        );

        assertEquals(5, results.size());

        assertEquals("Afternoon Workshop", results.get(0).getTitle());
        assertEquals("Conference", results.get(1).getTitle());
        assertEquals("Dentist Appointment", results.get(2).getTitle());
        assertEquals("Invalid Event", results.get(3).getTitle());
        assertEquals("Morning Meeting", results.get(4).getTitle());
    }

    @Test
    public void titleDescending_sortsTitlesReverseAlphabetically() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.TITLE_DESCENDING,
                fixedNow
        );

        assertEquals(5, results.size());

        assertEquals("Morning Meeting", results.get(0).getTitle());
        assertEquals("Invalid Event", results.get(1).getTitle());
        assertEquals("Dentist Appointment", results.get(2).getTitle());
        assertEquals("Conference", results.get(3).getTitle());
        assertEquals("Afternoon Workshop", results.get(4).getTitle());
    }

    @Test
    public void titleSorting_isCaseInsensitive() {
        Event lowercaseTitle = createEvent(
                "alpha event",
                "01/20/2026",
                "10:00 AM",
                ""
        );

        Event uppercaseTitle = createEvent(
                "Bravo Event",
                "01/20/2026",
                "11:00 AM",
                ""
        );

        List<Event> source = Arrays.asList(
                uppercaseTitle,
                lowercaseTitle
        );

        List<Event> results = EventAlgorithms.filterAndSort(
                source,
                "",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.TITLE_ASCENDING,
                fixedNow
        );

        assertSame(lowercaseTitle, results.get(0));
        assertSame(uppercaseTitle, results.get(1));
    }

    // ---------------------------------------------------------------------
    // Search tests
    // ---------------------------------------------------------------------

    @Test
    public void search_matchesEventTitle() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "conference",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(1, results.size());
        assertSame(upcomingEvent, results.get(0));
    }

    @Test
    public void search_matchesEventDescription() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "algorithms",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(1, results.size());
        assertSame(todayAfternoonEvent, results.get(0));
    }

    @Test
    public void search_matchesEventDate() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "01/15/2026",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(2, results.size());
        assertSame(todayMorningEvent, results.get(0));
        assertSame(todayAfternoonEvent, results.get(1));
    }

    @Test
    public void search_matchesEventTime() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "9:00 AM",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(2, results.size());
        assertSame(pastEvent, results.get(0));
        assertSame(todayMorningEvent, results.get(1));
    }

    @Test
    public void search_isCaseInsensitive() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "JAVA ALGORITHMS",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(1, results.size());
        assertSame(todayAfternoonEvent, results.get(0));
    }

    @Test
    public void search_supportsPartialMatches() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "confer",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(1, results.size());
        assertSame(upcomingEvent, results.get(0));
    }

    @Test
    public void search_requiresEveryQueryTermToMatch() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "java workshop",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(1, results.size());
        assertSame(todayAfternoonEvent, results.get(0));
    }

    @Test
    public void searchReturnsEmptyList_whenOneTermDoesNotMatch() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "java dentist",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertTrue(results.isEmpty());
    }

    @Test
    public void blankSearch_returnsAllEvents() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "   ",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(5, results.size());
    }

    @Test
    public void duplicateSearchTerms_doNotAffectResults() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "conference conference conference",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(1, results.size());
        assertSame(upcomingEvent, results.get(0));
    }

    // ---------------------------------------------------------------------
    // Date filtering tests
    // ---------------------------------------------------------------------

    @Test
    public void todayFilter_returnsOnlyEventsOnCurrentDate() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "",
                EventFilterOption.TODAY,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(2, results.size());
        assertSame(todayMorningEvent, results.get(0));
        assertSame(todayAfternoonEvent, results.get(1));
    }

    @Test
    public void upcomingFilter_returnsEventsAtOrAfterCurrentTime() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "",
                EventFilterOption.UPCOMING,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(2, results.size());
        assertSame(todayAfternoonEvent, results.get(0));
        assertSame(upcomingEvent, results.get(1));

        assertFalse(results.contains(todayMorningEvent));
        assertFalse(results.contains(pastEvent));
        assertFalse(results.contains(invalidDateEvent));
    }

    @Test
    public void pastFilter_returnsEventsBeforeCurrentTime() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "",
                EventFilterOption.PAST,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(2, results.size());
        assertSame(pastEvent, results.get(0));
        assertSame(todayMorningEvent, results.get(1));

        assertFalse(results.contains(todayAfternoonEvent));
        assertFalse(results.contains(upcomingEvent));
        assertFalse(results.contains(invalidDateEvent));
    }

    @Test
    public void eventAtExactCurrentTime_isUpcomingNotPast() {
        Event exactTimeEvent = createEvent(
                "Current Event",
                "01/15/2026",
                "12:00 PM",
                "Occurs exactly at the fixed current time"
        );

        List<Event> source = Arrays.asList(exactTimeEvent);

        List<Event> upcomingResults = EventAlgorithms.filterAndSort(
                source,
                "",
                EventFilterOption.UPCOMING,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        List<Event> pastResults = EventAlgorithms.filterAndSort(
                source,
                "",
                EventFilterOption.PAST,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(1, upcomingResults.size());
        assertSame(exactTimeEvent, upcomingResults.get(0));
        assertTrue(pastResults.isEmpty());
    }

    @Test
    public void allEventsFilter_includesInvalidDates() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(5, results.size());
        assertTrue(results.contains(invalidDateEvent));
    }

    @Test
    public void dateFilters_excludeInvalidDates() {
        List<Event> todayResults = EventAlgorithms.filterAndSort(
                events,
                "",
                EventFilterOption.TODAY,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        List<Event> upcomingResults = EventAlgorithms.filterAndSort(
                events,
                "",
                EventFilterOption.UPCOMING,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        List<Event> pastResults = EventAlgorithms.filterAndSort(
                events,
                "",
                EventFilterOption.PAST,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertFalse(todayResults.contains(invalidDateEvent));
        assertFalse(upcomingResults.contains(invalidDateEvent));
        assertFalse(pastResults.contains(invalidDateEvent));
    }

    // ---------------------------------------------------------------------
    // Combined operation tests
    // ---------------------------------------------------------------------

    @Test
    public void searchFilterAndSort_workTogether() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "workshop",
                EventFilterOption.TODAY,
                EventSortOption.TITLE_ASCENDING,
                fixedNow
        );

        assertEquals(1, results.size());
        assertSame(todayAfternoonEvent, results.get(0));
    }

    // ---------------------------------------------------------------------
    // Edge-case tests
    // ---------------------------------------------------------------------

    @Test
    public void nullSource_returnsEmptyList() {
        List<Event> results = EventAlgorithms.filterAndSort(
                null,
                "",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertTrue(results.isEmpty());
    }

    @Test
    public void emptySource_returnsEmptyList() {
        List<Event> results = EventAlgorithms.filterAndSort(
                new ArrayList<>(),
                "",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertTrue(results.isEmpty());
    }

    @Test
    public void nullQuery_isTreatedAsBlankSearch() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                null,
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(5, results.size());
    }

    @Test
    public void nullFilter_defaultsToAllEvents() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "",
                null,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(5, results.size());
        assertTrue(results.contains(invalidDateEvent));
    }

    @Test
    public void nullSort_defaultsToDateAscending() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "",
                EventFilterOption.ALL_EVENTS,
                null,
                fixedNow
        );

        assertEquals(5, results.size());
        assertSame(pastEvent, results.get(0));
        assertSame(todayMorningEvent, results.get(1));
        assertSame(todayAfternoonEvent, results.get(2));
        assertSame(upcomingEvent, results.get(3));
        assertSame(invalidDateEvent, results.get(4));
    }

    @Test
    public void nullCurrentTime_usesCurrentSystemTimeWithoutCrashing() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                null
        );

        assertEquals(5, results.size());
    }

    @Test
    public void nullEventsInsideSource_areIgnored() {
        List<Event> source = new ArrayList<>();
        source.add(todayMorningEvent);
        source.add(null);
        source.add(upcomingEvent);

        List<Event> results = EventAlgorithms.filterAndSort(
                source,
                "",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(2, results.size());
        assertSame(todayMorningEvent, results.get(0));
        assertSame(upcomingEvent, results.get(1));
    }

    @Test
    public void filteringAndSorting_doNotModifyOriginalList() {
        List<Event> originalOrder = new ArrayList<>(events);

        EventAlgorithms.filterAndSort(
                events,
                "",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.DATE_ASCENDING,
                fixedNow
        );

        assertEquals(originalOrder.size(), events.size());

        for (int index = 0; index < originalOrder.size(); index++) {
            assertSame(originalOrder.get(index), events.get(index));
        }
    }

    // ---------------------------------------------------------------------
    // Compatibility-overload test
    // ---------------------------------------------------------------------

    @Test
    public void compatibilityOverload_defaultsToAllEvents() {
        List<Event> results = EventAlgorithms.filterAndSort(
                events,
                "",
                EventSortOption.DATE_ASCENDING
        );

        assertEquals(5, results.size());
        assertTrue(results.contains(invalidDateEvent));
    }

    // ---------------------------------------------------------------------
    // Larger-data test
    // ---------------------------------------------------------------------

    @Test
    public void titleSort_handlesLargeDataset() {
        List<Event> largeDataset = new ArrayList<>();

        for (int index = 1000; index >= 1; index--) {
            String title = String.format(
                    java.util.Locale.US,
                    "Event %04d",
                    index
            );

            largeDataset.add(createEvent(
                    title,
                    "01/20/2026",
                    "10:00 AM",
                    "Performance test event"
            ));
        }

        List<Event> results = EventAlgorithms.filterAndSort(
                largeDataset,
                "",
                EventFilterOption.ALL_EVENTS,
                EventSortOption.TITLE_ASCENDING,
                fixedNow
        );

        assertEquals(1000, results.size());
        assertEquals("Event 0001", results.get(0).getTitle());
        assertEquals("Event 1000", results.get(999).getTitle());
    }

    // ---------------------------------------------------------------------
    // Test helper
    // ---------------------------------------------------------------------

    private Event createEvent(
            String title,
            String date,
            String time,
            String description
    ) {
        return new Event(title, date, time, description);
    }
}